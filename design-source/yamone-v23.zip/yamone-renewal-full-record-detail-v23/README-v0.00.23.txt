Yamone Renewal v0.00.23
Base: yamone-renewal-full-record-detail-v22(1).zip

Settings-only changes
- 활동 기록 settings menu removed
- 자동감지 master ON/OFF controls 걷기/달리기/자전거 together
- each of the 3 activities can be changed individually
- Snow: auto detect, offline map
- Sleep: snore detect, sensitivity
- Alarm: snooze, vibration
- Permissions: location / notification / microphone / background
- Data/Storage: no export
- Delete all records separately for 이동 활동 / Snow / 수면
- delete confirmation required
- App info shows Version 0.00.23
- hidden developer mode: tap app/version card 7 times
