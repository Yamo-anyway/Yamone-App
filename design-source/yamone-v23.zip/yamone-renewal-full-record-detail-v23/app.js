const screen=document.getElementById('screen');const tabs=[...document.querySelectorAll('.nav')];const toast=document.getElementById('toast');const phone=document.querySelector('.phone');const moveOverlay=document.getElementById('moveOverlay');let tab='home',openMonth=null,view='main',moveState='ready',moveMode='auto',moveSubtype='run',snowState='ready',snowMotion='downhill',sleepState='ready',sleepPlaying=false,sleepPosition=0,locationState='landing',locationSharingActive=false,locationStartAt=null,locationShareUntil=null,locationInterval=60,locationRoomName='',locationNickname='야모',locationCreateMode=true,locationRoomChecked=false,locationRefreshLeft=60,locationManualUnlockAt=0,locationSelectedMember='self',locationOwnStatus='normal',locationExtendChoice=60,locationPermissionGranted=false,locationNotificationGranted=false,locationNetworkOnline=true,locationLastSnapshotAt=null,locationInitialRefreshStep=0,locationExpiryWarned=false,locationFastRefreshTimers=[],recordDetailId=null,recordFilter='all',recordSelectedSegment=7,deletedRecordIds=[],sleepCandidatePlaying=null,sleepCandidateDeleted=[],sleepFalsePositiveIds=[],sleepUploadedIds=[],sleepPlaybackSec=0,sleepGraphPlaying=false,sleepRecordAudioTimer=null,sleepCandidateProgress={},sleepCandidateAudioTimer=null,snowSelectedRunId='run3',snowMapSubmissionIds=[],snowLocalNames={},snowLiftLocalNames={},snowMapVersion=12,snowMapUpdateAvailable=true,snowRunDetailOpen=false,snowSelectedDescentId='descent1',snowMainScrollTop=0;

let settingPage=null,appInfoTapCount=0;
const settingsState={
  autoDetect:true,
  detectWalk:true,
  detectRun:true,
  detectBike:true,
  snowAutoDetect:true,
  sleepSnore:true,
  sleepSensitivity:'normal',
  alarmSnooze:'10',
  alarmVibrate:true
};
const A='assets/';
const assetInventory=[
  {file:'title-location.png',label:'위치공유',use:'위치공유 준비 상단'},
  {file:'title-location-live.png',label:'위치공유 중',use:'위치공유 진행 상단'},
  {file:'title-alarm.png',label:'알람',use:'알람 목록/편집 상단'},
  {file:'title-sleep.png',label:'수면',use:'수면 준비 상단'},
  {file:'title-sleep-live.png',label:'수면 기록',use:'수면 기록/결과 상단'},
  {file:'title-snow.png',label:'Snow',use:'Snow 준비 상단'},
  {file:'title-snow-live.png',label:'Snow 기록',use:'Snow 기록/요약 상단'},
  {file:'walk.png',label:'걷기',use:'이동 활동 상세'},
  {file:'run.png',label:'달리기',use:'이동 활동 상세'},
  {file:'bike.png',label:'자전거',use:'이동 활동 상세'},
  {file:'route.png',label:'운동 경로',use:'이동 활동 상세'},
  {file:'pace.png',label:'페이스',use:'이동 활동 상세'},
  {file:'speed.png',label:'속도',use:'이동 활동 상세'},
  {file:'gps.png',label:'GPS 신호',use:'이동 활동 상세'},
  {file:'pause.png',label:'일시정지',use:'이동 활동 상세'},
  {file:'resume.png',label:'다시 시작',use:'이동 활동 상세'},
  {file:'stop.png',label:'운동 종료',use:'이동 활동 상세'},
  {file:'activity-move.png',label:'걷기 · 달리기 · 자전거',use:'활동 카드 / 기록 썸네일'},
  {file:'activity-snow.png',label:'Snow',use:'활동 카드 / 기록 썸네일'},
  {file:'activity-location.png',label:'위치공유',use:'활동 카드'},
  {file:'activity-sleep.png',label:'수면',use:'활동 카드 / 기록 썸네일'},
  {file:'nav-home.png',label:'홈 탭',use:'하단 탭'},
  {file:'nav-activity.png',label:'활동 탭',use:'하단 탭'},
  {file:'nav-records.png',label:'기록 탭',use:'하단 탭'},
  {file:'nav-alarm.png',label:'알람 탭',use:'하단 탭 / 알람 힌트'},
  {file:'nav-settings.png',label:'설정 탭',use:'하단 탭'},
  {file:'settings-activity-record.png',label:'활동 기록',use:'설정 메뉴'},
  {file:'settings-auto-detect.png',label:'자동감지',use:'설정 메뉴'},
  {file:'settings-snow.png',label:'Snow',use:'설정 메뉴'},
  {file:'settings-sleep.png',label:'수면',use:'설정 메뉴'},
  {file:'settings-alarm.png',label:'알람',use:'설정 메뉴'},
  {file:'settings-permission.png',label:'권한',use:'설정 메뉴'},
  {file:'settings-data-storage.png',label:'데이터 / 저장',use:'설정 메뉴'},
  {file:'settings-app-info.png',label:'앱 정보',use:'설정 메뉴'},
  {file:'stat-time.png',label:'활동 시간',use:'홈 통계'},
  {file:'stat-distance.png',label:'이동 거리',use:'홈 통계'},
  {file:'stat-calorie.png',label:'칼로리',use:'홈 통계'}
];
function buildAssetList(){const box=document.getElementById('assetList');if(!box)return;box.innerHTML=assetInventory.map(a=>`<div class="asset-item"><img src="${A}${a.file}" alt=""><div><b>${a.label}</b><small>${a.use}</small></div></div>`).join('')}
function say(s){toast.textContent=s;toast.classList.add('show');clearTimeout(window.tt);window.tt=setTimeout(()=>toast.classList.remove('show'),1600)}
function renderHome(){
  const running=locationSharingActive?`
    <div class="running-section">
      <div class="running-title">현재 진행 중</div>
      <div class="card running-card" id="homeLocationRunning">
        <img src="${A}activity-location.png" alt="">
        <div class="running-card-copy">
          <b>위치공유 중 · ${escapeLoc(locationRoomName||'야모네 스키 여행')}</b>
          <small>참여 ${locationMembers.length}명 · ${remainingLocationText()} · 위치 ${locationInterval/60}분 간격</small>
        </div>
        <span class="running-card-pill">보기</span>
      </div>
    </div>`:'';
  screen.innerHTML=`<div class="brand">야모네</div><div class="title-asset-wrap"><img class="title-asset title-home" src="${A}title-home.png" alt="오늘의 활동"></div><div class="home-version">Version 0.00.23</div><div class="stats"><div class="card stat"><img src="${A}stat-time.png"><span>활동 시간</span><strong>0분</strong></div><div class="card stat"><img src="${A}stat-distance.png"><span>이동 거리</span><strong>0.0 km</strong></div><div class="card stat"><img src="${A}stat-calorie.png"><span>칼로리</span><strong>0 kcal</strong></div></div>${running}${locationSharingActive?'':`<div class="empty"><img src="${A}empty-shoe.png"><b>지금 활동을 시작하면<br>여기에 기록이 표시됩니다.</b><p>걷기, 달리기, 자전거 등 다양한 활동을<br>시작해보세요!</p></div>`}`;
  const runningCard=document.getElementById('homeLocationRunning');
  if(runningCard)runningCard.onclick=()=>{view='location';locationState='active';render()};
}
function ac(icon,title,sub,badge=''){return `<div class="card activity-card" data-name="${title}"><img class="asset" src="${A}${icon}.png"><div class="activity-copy"><b>${title}</b><small>${sub}</small>${badge?`<span class="badge">${badge}</span>`:''}</div><span class="arrow">›</span></div>`}
function renderActivity(){
screen.innerHTML=`<div class="title-asset-wrap"><img class="title-asset title-activity" src="${A}title-activity.png" alt="활동"></div><div class="activity-list">
${ac('activity-move','걷기 · 달리기 · 자전거','자동으로 활동을 구분해 기록','자동감지 켜짐')}
${ac('activity-snow','Snow','스키 · 스노보드 기록')}
${ac('activity-location','위치공유','방 참여자끼리 마지막 위치 확인',locationSharingActive?'공유 중':'')}
${ac('activity-sleep','수면','수면과 코골이 후보를 기록')}</div>`;
document.querySelectorAll('[data-name]').forEach(x=>x.onclick=()=>{
  if(x.dataset.name==='걷기 · 달리기 · 자전거'){view='move';moveState='ready';render();}
  else if(x.dataset.name==='Snow'){view='snow';snowState='ready';render();}
  else if(x.dataset.name==='위치공유'){view='location';locationState=locationSharingActive?'active':'landing';render();}
  else if(x.dataset.name==='수면'){view='sleep';sleepState='ready';sleepPlaying=false;sleepPosition=0;render();}
});
}

const recordSamples={
  run1:{
    id:'run1',kind:'move',mode:'run',icon:'activity-move',title:'오전 달리기',
    date:'2026년 8월 20일 (목) 07:10',distance:'5.2 km',duration:'32분 14초',
    avg:'6:12 /km',max:'14.8 km/h',cal:'382 kcal',gain:'+118 m',loss:'-121 m',
    startElev:86,endElev:83,window:100,refresh:25
  },
  bike1:{
    id:'bike1',kind:'move',mode:'bike',icon:'activity-move',title:'자전거 라이딩',
    date:'2026년 8월 19일 (수) 18:20',distance:'12.4 km',duration:'48분 08초',
    avg:'15.5 km/h',max:'36.2 km/h',cal:'514 kcal',gain:'+246 m',loss:'-238 m',
    startElev:74,endElev:82,window:200,refresh:50
  },
  snow1:{
    id:'snow1',kind:'snow',mode:'snow',icon:'activity-snow',title:'Snow',
    date:'2026년 8월 18일 (화) 10:15',distance:'3.1 km',duration:'1시간 12분',
    avg:'18.4 km/h',max:'52.8 km/h',cal:'436 kcal',gain:'+312 m',loss:'-326 m',
    startElev:1510,endElev:1496,window:100,refresh:25
  },
  sleep1:{
    id:'sleep1',kind:'sleep',mode:'sleep',icon:'activity-sleep',title:'수면',
    date:'2026년 8월 17일 (월) 23:30',distance:'7시간 25분',duration:'수면 기록',
    sleepTotal:'7시간 25분',snore:'11회',soundAvg:'31 dB',soundMax:'58 dB'
  }
};

const runGrades=[0.8,1.5,3.2,5.6,8.8,11.6,7.4,3.8,1.1,-1.0,-3.5,-6.8,-10.9,-13.7,-9.4,-5.1,-2.7,0.4,2.8,6.3,9.1,5.0,1.3,-2.5,-5.9,-3.0];
const bikeGrades=[0.4,1.7,2.8,4.4,6.2,8.9,11.7,9.5,6.6,3.4,1.2,-1.1,-3.2,-5.7,-8.8,-11.4,-14.8,-10.5,-7.2,-4.6,-1.8,0.6,3.1,5.4,7.8,4.1,1.0,-2.8,-5.6,-7.4,-3.3,0.8];
const snowGrades=[-3.2,-5.8,-8.4,-12.7,-17.2,-21.5,-16.1,-10.2,-5.4,-1.2,2.7,7.5,13.2,18.6,11.4,4.2,0.5,-4.8,-9.9,-15.8,-20.1,-14.6,-8.0,-3.6];

const kmSplits={
  run1:[
    {km:1,time:'06:24',pace:'6:24 /km',speed:'9.4 km/h',elev:'+18 m'},
    {km:2,time:'06:06',pace:'6:06 /km',speed:'9.8 km/h',elev:'+31 m'},
    {km:3,time:'05:58',pace:'5:58 /km',speed:'10.1 km/h',elev:'-12 m'},
    {km:4,time:'06:18',pace:'6:18 /km',speed:'9.5 km/h',elev:'+39 m'},
    {km:5,time:'06:03',pace:'6:03 /km',speed:'9.9 km/h',elev:'-51 m'},
    {km:5.2,time:'01:25',pace:'7:05 /km',speed:'8.5 km/h',elev:'-4 m'}
  ],
  bike1:[
    {km:1,time:'04:20',pace:'-',speed:'13.8 km/h',elev:'+14 m'},
    {km:2,time:'03:51',pace:'-',speed:'15.6 km/h',elev:'+26 m'},
    {km:3,time:'03:26',pace:'-',speed:'17.5 km/h',elev:'+39 m'},
    {km:4,time:'04:05',pace:'-',speed:'14.7 km/h',elev:'+44 m'},
    {km:5,time:'03:18',pace:'-',speed:'18.2 km/h',elev:'-12 m'},
    {km:6,time:'02:54',pace:'-',speed:'20.7 km/h',elev:'-36 m'},
    {km:7,time:'03:42',pace:'-',speed:'16.2 km/h',elev:'+28 m'},
    {km:8,time:'04:11',pace:'-',speed:'14.3 km/h',elev:'+52 m'},
    {km:9,time:'03:07',pace:'-',speed:'19.2 km/h',elev:'-42 m'},
    {km:10,time:'02:48',pace:'-',speed:'21.4 km/h',elev:'-58 m'},
    {km:11,time:'03:44',pace:'-',speed:'16.1 km/h',elev:'+21 m'},
    {km:12,time:'03:09',pace:'-',speed:'19.0 km/h',elev:'-19 m'},
    {km:12.4,time:'01:33',pace:'-',speed:'15.5 km/h',elev:'-3 m'}
  ]
};

const bikeSpeedSeries=[12,14,15,17,16,18,21,24,19,16,15,17,22,27,31,29,25,20,18,16,14,15,19,23,28,33,36,30,24,20,18,16,17,19,22,25,27,23,20,18,16,15];

const snowSlopeStats=[
  {name:'Summit Run',runs:4,distance:'1.12 km',avg:'31.4 km/h',max:'48.7 km/h',vertical:'-420 m'},
  {name:'Alpine Way',runs:3,distance:'0.86 km',avg:'27.1 km/h',max:'44.2 km/h',vertical:'-318 m'},
  {name:'Easy Street',runs:2,distance:'0.54 km',avg:'18.6 km/h',max:'31.9 km/h',vertical:'-166 m'},
  {name:'Connector',runs:1,distance:'0.21 km',avg:'14.2 km/h',max:'22.3 km/h',vertical:'-42 m'}
];

const snowDescents=[
  {
    id:'descent1',label:'활주 1',start:'10:15:32',end:'10:24:41',duration:'9분 09초',
    avg:'26.4 km/h',max:'45.7 km/h',distance:'1.07 km',vertical:'-325 m',
    segments:[
      {id:'seg1',name:'A 슬로프',type:'slope',start:'10:15:32',end:'10:18:50',duration:'3분 18초',distance:'0.46 km',avg:'27.8 km/h',max:'42.1 km/h',vertical:'-138 m'},
      {id:'seg2',name:'B 슬로프',type:'slope',start:'10:18:50',end:'10:21:44',duration:'2분 54초',distance:'0.39 km',avg:'29.6 km/h',max:'45.7 km/h',vertical:'-126 m'},
      {id:'seg3',name:'미확인',type:'unknown',start:'10:21:44',end:'10:23:30',duration:'1분 46초',distance:'0.22 km',avg:'21.1 km/h',max:'32.4 km/h',vertical:'-61 m'}
    ]
  },
  {
    id:'descent2',label:'활주 2',start:'10:42:08',end:'10:51:13',duration:'9분 05초',
    avg:'27.9 km/h',max:'48.7 km/h',distance:'1.26 km',vertical:'-399 m',
    segments:[
      {id:'seg4',name:'트리런',type:'tree',start:'10:42:08',end:'10:44:36',duration:'2분 28초',distance:'0.31 km',avg:'24.4 km/h',max:'37.8 km/h',vertical:'-104 m'},
      {id:'seg5',name:'A 슬로프',type:'slope',start:'10:44:36',end:'10:48:07',duration:'3분 31초',distance:'0.51 km',avg:'30.2 km/h',max:'48.7 km/h',vertical:'-154 m'},
      {id:'seg6',name:'C 슬로프',type:'slope',start:'10:48:07',end:'10:51:13',duration:'3분 06초',distance:'0.44 km',avg:'28.9 km/h',max:'44.6 km/h',vertical:'-141 m'}
    ]
  },
  {
    id:'descent3',label:'활주 3',start:'11:16:25',end:'11:22:58',duration:'6분 33초',
    avg:'23.7 km/h',max:'41.3 km/h',distance:'0.84 km',vertical:'-222 m',
    segments:[
      {id:'seg7',name:'D 슬로프',type:'slope',start:'11:16:25',end:'11:20:14',duration:'3분 49초',distance:'0.52 km',avg:'25.9 km/h',max:'41.3 km/h',vertical:'-151 m'},
      {id:'seg8',name:'미확인',type:'unknown',start:'11:20:14',end:'11:22:58',duration:'2분 44초',distance:'0.32 km',avg:'18.7 km/h',max:'29.8 km/h',vertical:'-71 m'}
    ]
  }
];

const snowRunSegments=snowDescents.flatMap(d=>d.segments);

const snowLiftStats=[
  {name:'Summit Chair',rides:4,time:'28분',distance:'2.8 km'},
  {name:'Alpine T-Bar',rides:3,time:'17분',distance:'1.4 km'},
  {name:'Village Gondola',rides:1,time:'9분',distance:'1.1 km'}
];

const snowLiftColorMap={
  'Summit Chair':'#d9a83e',
  'Alpine T-Bar':'#2aa7a1',
  'Village Gondola':'#344f9e'
};

function snowLiftRouteColor(name){
  return snowLiftColorMap[name]||'#7a8790';
}

const snowFullRoute=[
  {kind:'segment',id:'seg1',name:'A 슬로프',type:'slope'},
  {kind:'segment',id:'seg2',name:'B 슬로프',type:'slope'},
  {kind:'segment',id:'seg3',name:'미확인',type:'unknown'},
  {kind:'lift',id:'lift0',name:'Summit Chair',liftIndex:0},
  {kind:'segment',id:'seg4',name:'트리런',type:'tree'},
  {kind:'segment',id:'seg5',name:'A 슬로프',type:'slope'},
  {kind:'segment',id:'seg6',name:'C 슬로프',type:'slope'},
  {kind:'lift',id:'lift1',name:'Alpine T-Bar',liftIndex:1},
  {kind:'segment',id:'seg7',name:'D 슬로프',type:'slope'},
  {kind:'segment',id:'seg8',name:'미확인',type:'unknown'},
  {kind:'lift',id:'lift2',name:'Village Gondola',liftIndex:2}
];

function snowFullRouteName(item){
  if(item.kind==='lift'){
    const lift=snowLiftStats[item.liftIndex];
    return lift?snowLiftDisplayName(lift,item.liftIndex):item.name;
  }
  const seg=snowRunSegments.find(x=>x.id===item.id);
  return seg?snowRunDisplayName(seg):item.name;
}

function snowFullRouteColor(item){
  if(item.kind==='lift')return snowLiftRouteColor(snowFullRouteName(item));
  const seg=snowRunSegments.find(x=>x.id===item.id);
  if(seg && typeof snowSegmentColor==='function')return snowSegmentColor(seg);
  if(item.type==='tree')return '#8c65c7';
  if(item.type==='unknown')return '#9aa5ad';
  return '#4e9fda';
}


const sleepDbSeries=[27,26,28,29,30,31,29,28,30,34,48,42,31,29,32,37,54,45,33,30,32,41,57,44,34,29,31,39,35,28,27,30,33,29,28,26];

const sleepCandidates=[
  {id:'s1',time:'00:42:18',duration:'12초',score:'높음',db:'48 dB'},
  {id:'s2',time:'01:15:40',duration:'8초',score:'중간',db:'43 dB'},
  {id:'s3',time:'02:07:13',duration:'17초',score:'높음',db:'54 dB'},
  {id:'s4',time:'03:34:52',duration:'10초',score:'중간',db:'46 dB'},
  {id:'s5',time:'04:28:09',duration:'14초',score:'높음',db:'57 dB'},
  {id:'s6',time:'05:51:31',duration:'9초',score:'낮음',db:'39 dB'}
];


const recordRouteXY=[
 [10,74],[16,70],[22,65],[27,57],[32,49],[38,42],[45,36],[52,32],
 [59,35],[65,41],[71,48],[77,55],[83,62],[88,69],[84,77],[76,82],
 [67,80],[58,75],[50,69],[42,72],[35,79],[28,84],[22,79],[17,72],
 [13,65],[10,58],[15,51],[22,46],[30,42],[39,39],[49,43],[58,49]
];

let recordElevationCache={};

function recordListItem(id){
  const r=recordSamples[id];
  if(!r || deletedRecordIds.includes(id))return '';
  return `<button class="card record record-open" data-record="${id}">
    <img src="${A}${r.icon}.png">
    <div class="record-copy"><b>${r.title}</b><small>${r.date}</small></div>
    <div class="record-value"><b>${r.distance}</b><small>${r.duration}</small></div>
  </button>`;
}
function month(label,key){
  let o=openMonth===key;
  return `<div class="card month ${o?'open':''}" data-month="${key}">
    <button><span>${label}</span><img src="${A}${o?'nav-activity':'nav-records'}.png" alt=""></button>
    <div class="month-content">${o?'8월 23일 · 걷기 + 달리기 · 4.1 km · 48분':'기록 보기'}</div>
  </div>`;
}
function renderRecords(){
  const ids=['run1','bike1','snow1','sleep1'].filter(id=>{
    if(recordFilter==='all')return true;
    return recordSamples[id].kind===recordFilter;
  });
  screen.innerHTML=`<h1 class="title">기록</h1>
    <div class="filters">
      <button class="filter ${recordFilter==='all'?'active':''}" data-record-filter="all">전체</button>
      <button class="filter ${recordFilter==='move'?'active':''}" data-record-filter="move">이동</button>
      <button class="filter ${recordFilter==='snow'?'active':''}" data-record-filter="snow">Snow</button>
      <button class="filter ${recordFilter==='sleep'?'active':''}" data-record-filter="sleep">수면</button>
    </div>
    <div class="section">최근 기록</div>
    ${ids.map(recordListItem).join('')||`<div class="record-empty">표시할 기록이 없습니다.</div>`}
    <div class="section">이전 기록</div>${month('2026년 08월',8)}${month('2026년 07월',7)}`;

  document.querySelectorAll('[data-record-filter]').forEach(b=>b.onclick=()=>{
    recordFilter=b.dataset.recordFilter;renderRecords();
  });
  document.querySelectorAll('[data-record]').forEach(b=>b.onclick=()=>{
    recordDetailId=b.dataset.record;
    recordSelectedSegment=7;
    view='record-detail';
    render();
  });
  document.querySelectorAll('[data-month]').forEach(m=>m.querySelector('button').onclick=()=>{
    let k=+m.dataset.month;openMonth=openMonth===k?null:k;renderRecords();
  });
}

function mixHex(a,b,t){
  t=Math.max(0,Math.min(1,t));
  const pa=a.replace('#',''),pb=b.replace('#','');
  const ar=parseInt(pa.slice(0,2),16),ag=parseInt(pa.slice(2,4),16),ab=parseInt(pa.slice(4,6),16);
  const br=parseInt(pb.slice(0,2),16),bg=parseInt(pb.slice(2,4),16),bb=parseInt(pb.slice(4,6),16);
  const x=v=>Math.round(v).toString(16).padStart(2,'0');
  return '#'+x(ar+(br-ar)*t)+x(ag+(bg-ag)*t)+x(ab+(bb-ab)*t);
}
function slopeColor(s){
  if(s<-2){
    const t=Math.min(1,(-s-2)/18);
    return mixHex('#bfe8ff','#164fb7',t);
  }
  if(s>2){
    const t=Math.min(1,(s-2)/18);
    return mixHex('#ffcaca','#bf2f42',t);
  }
  const t=Math.min(1,Math.abs(s)/2);
  return mixHex('#6acb8d','#47ae72',t*.35);
}
function slopeLabel(s){
  if(s<=-15)return '매우 강한 내리막';
  if(s<=-10)return '강한 내리막';
  if(s<=-5)return '내리막';
  if(s<-2)return '완만한 내리막';
  if(s<=2)return '평지';
  if(s<5)return '완만한 오르막';
  if(s<10)return '오르막';
  if(s<15)return '강한 오르막';
  return '매우 강한 오르막';
}
function recordGrades(r){
  return r.mode==='bike'?bikeGrades:r.mode==='snow'?snowGrades:runGrades;
}
function elevationPoints(r){
  if(recordElevationCache[r.id])return recordElevationCache[r.id];
  const grades=recordGrades(r);
  const totalKm=parseFloat(r.distance);
  const segM=totalKm*1000/grades.length;
  let elev=r.startElev||80;
  const pts=[elev];
  grades.forEach(g=>{
    elev += segM*(g/100);
    pts.push(elev);
  });
  const target=r.endElev;
  const drift=(target-pts[pts.length-1]);
  const adjusted=pts.map((v,i)=>v+drift*(i/(pts.length-1)));
  recordElevationCache[r.id]=adjusted;
  return adjusted;
}
function lineSegmentStyle(x1,y1,x2,y2,color,width=4){
  const dx=x2-x1,dy=y2-y1,len=Math.sqrt(dx*dx+dy*dy),ang=Math.atan2(dy,dx)*180/Math.PI;
  return `left:${x1}%;top:${y1}%;width:${len}%;transform:rotate(${ang}deg);background:${color};height:${width}px`;
}
function snowRunDisplayName(run){
  return snowLocalNames[run.id]||run.name;
}
function snowLiftDisplayName(lift,index){
  return snowLiftLocalNames[index]||lift.name;
}
function snowRunById(id){
  return snowRunSegments.find(x=>x.id===id)||snowRunSegments[0];
}
function snowDescentById(id){
  return snowDescents.find(x=>x.id===id)||snowDescents[0];
}
function snowSegmentById(id){
  return snowRunSegments.find(x=>x.id===id)||snowRunSegments[0];
}
function snowRouteMarkup(){
  const route=snowFullRoute;
  const basePts=[
    [10,74],[16,67],[23,59],[31,50],[40,43],[49,38],
    [58,42],[67,50],[76,59],[84,68],[78,78],[67,82]
  ];
  const pts=basePts.slice(0,route.length+1);

  return `<div class="detail-map snow-run-map snow-full-route-map">
    <span class="detail-map-road a"></span>
    <span class="detail-map-road b"></span>
    <span class="detail-map-road c"></span>

    ${route.map((item,i)=>{
      const a=pts[i],b=pts[i+1]||pts[i];
      const color=snowFullRouteColor(item);
      const isLift=item.kind==='lift';
      return `<span
        class="snow-full-route-seg ${isLift?'lift':'run'}"
        data-full-route="${item.id}"
        title="${escapeLoc(snowFullRouteName(item))}"
        style="${lineSegmentStyle(a[0],a[1],b[0],b[1],color,isLift?7:8)}"
      ></span>`;
    }).join('')}

    <span class="map-start">S</span>
    <span class="map-end">E</span>
  </div>`;
}
function routeMarkup(r){
  if(r.mode==='snow')return snowRouteMarkup();
  const grades=recordGrades(r);
  const pts=recordRouteXY.slice(0,grades.length+1);
  return `<div class="detail-map">
    <span class="detail-map-road a"></span><span class="detail-map-road b"></span><span class="detail-map-road c"></span>
    ${grades.map((g,i)=>{
      const a=pts[i],b=pts[i+1]||pts[i];
      return `<button class="grade-route-seg ${recordSelectedSegment===i?'selected':''}" data-grade-seg="${i}"
        title="${g.toFixed(1)}%" style="${lineSegmentStyle(a[0],a[1],b[0],b[1],slopeColor(g),recordSelectedSegment===i?7:5)}"></button>`;
    }).join('')}
    <span class="map-start">S</span><span class="map-end">E</span>
  </div>`;
}
function elevationMarkup(r){
  const grades=recordGrades(r),pts=elevationPoints(r);
  const min=Math.min(...pts)-5,max=Math.max(...pts)+5,span=Math.max(1,max-min);
  const xy=pts.map((e,i)=>[
    5+(90*i/(pts.length-1)),
    88-(72*(e-min)/span)
  ]);
  return `<div class="elev-chart">
    <div class="elev-grid g1"></div><div class="elev-grid g2"></div><div class="elev-grid g3"></div>
    ${grades.map((g,i)=>{
      const a=xy[i],b=xy[i+1];
      return `<button class="elev-line-seg ${recordSelectedSegment===i?'selected':''}" data-grade-seg="${i}"
        style="${lineSegmentStyle(a[0],a[1],b[0],b[1],slopeColor(g),recordSelectedSegment===i?6:4)}"></button>`;
    }).join('')}
    <span class="elev-max">${Math.round(max-5)}m</span><span class="elev-min">${Math.round(min+5)}m</span>
  </div>`;
}
function gradeLegend(){
  return `<div class="grade-legend">
    <div class="grade-gradient"></div>
    <div class="grade-legend-labels"><span>강한 내리막</span><span>평지</span><span>강한 오르막</span></div>
  </div>`;
}
function selectedGradeInfo(r){
  const grades=recordGrades(r);
  const i=Math.min(recordSelectedSegment,grades.length-1);
  const g=grades[i];
  const totalM=parseFloat(r.distance)*1000;
  const startM=Math.round(totalM*i/grades.length);
  const endM=Math.round(totalM*(i+1)/grades.length);
  const dz=((endM-startM)*g/100);
  return {i,g,startM,endM,dz,label:slopeLabel(g),color:slopeColor(g)};
}
function recordDetailHeader(r){
  let titleAsset=r.kind==='snow'?'title-snow-live.png':r.kind==='sleep'?'title-sleep-live.png':'title-move-live.png';
  return `<div class="move-sticky"><div class="move-header-row">
    <button id="recordDetailBack" class="move-back-asset-btn"><img class="move-back-asset" src="${A}back-ready.png" alt="뒤로가기"></button>
    <img class="record-detail-title" src="${A}${titleAsset}" alt="기록 상세">
    <span class="record-detail-head-label">상세</span>
  </div></div>`;
}

function kmSplitMarkup(r){
  const rows=kmSplits[r.id]||[];
  if(!rows.length)return '';
  const isBike=r.mode==='bike';
  return `<div class="detail-section-head"><b>${isBike?'km별 속도':'km별 페이스'}</b><small>1 km 기준</small></div>
    <div class="card split-card">
      <div class="split-head"><span>구간</span><span>시간</span><span>${isBike?'평균속도':'페이스'}</span><span>고도</span></div>
      ${rows.map(x=>`<div class="split-row"><b>${x.km} km</b><span>${x.time}</span><span>${isBike?x.speed:x.pace}</span><span>${x.elev}</span></div>`).join('')}
    </div>`;
}
function simpleLineGraph(values,unit,maxOverride=null){
  const max=maxOverride||Math.max(...values)*1.08;
  const min=Math.min(...values)*0.9;
  const span=Math.max(1,max-min);
  const xy=values.map((v,i)=>[4+(92*i/(values.length-1)),90-(75*(v-min)/span)]);
  return `<div class="metric-line-chart">
    <div class="metric-grid a"></div><div class="metric-grid b"></div><div class="metric-grid c"></div>
    ${xy.slice(0,-1).map((a,i)=>{const b=xy[i+1];return `<i style="${lineSegmentStyle(a[0],a[1],b[0],b[1],'#5f7890',4)}"></i>`;}).join('')}
    <span class="metric-top">${Math.round(max)} ${unit}</span><span class="metric-bottom">${Math.round(min)} ${unit}</span>
  </div>`;
}
function bikeSpeedGraphMarkup(){
  return `<div class="detail-section-head"><b>속도 그래프</b><small>전체 라이딩</small></div>
    <div class="card metric-graph-card">
      ${simpleLineGraph(bikeSpeedSeries,'km/h',40)}
      <div class="metric-summary-row"><span>평균 <b>15.5 km/h</b></span><span>최고 <b>36.2 km/h</b></span></div>
    </div>`;
}
function snowDescentNames(descent){
  return descent.segments.map(seg=>escapeLoc(snowRunDisplayName(seg))).join(' · ');
}
function snowDescentRow(descent,index){
  return `<button class="snow-descent-row ${snowSelectedDescentId===descent.id?'selected':''}" data-snow-descent="${descent.id}">
    <div class="snow-descent-top">
      <b>${descent.label}</b>
      <span>${descent.start} → ${descent.end} · ${descent.duration}</span>
    </div>
    <div class="snow-descent-speed">
      <span>평균 <b>${descent.avg}</b></span>
      <span>최고 <b>${descent.max}</b></span>
      <span>${descent.distance}</span>
      <i>›</i>
    </div>
    <div class="snow-descent-segments">${snowDescentNames(descent)}</div>
  </button>`;
}
function snowMapUpdateCard(){
  return `<div class="card snow-map-update-card">
    <div class="snow-map-update-head">
      <div><small>오프라인 스키장 지도</small><b>지도 버전 ${snowMapVersion}</b></div>
      <span class="${snowMapUpdateAvailable?'available':''}">${snowMapUpdateAvailable?'새 지도 있음':'최신'}</span>
    </div>
    <p>사용자가 보낸 슬로프·트리런·리프트 수정은 선택한 근처 구간만 검토한 뒤 다음 지도 파일에 반영할 수 있습니다.</p>
    ${snowMapUpdateAvailable?`<button id="snowMapDownload">새 지도 다운로드</button>`:''}
    <small class="snow-osm-credit">OpenStreetMap 기반 오프라인 지도 · ODbL 출처 표기 유지</small>
  </div>`;
}
function snowExtendedMarkup(r){
  return `
    <div class="detail-section-head"><b>Snow 요약</b><small>하루 기록 · 같은 스키장 기준 합산</small></div>
    <div class="detail-stat-grid snow-extra-grid">
      <div class="card"><span>전체 활주 거리</span><b>3.17 km</b></div>
      <div class="card"><span>전체 이동 거리</span><b>${r.distance}</b></div>
      <div class="card"><span>활주 횟수</span><b>${snowDescents.length}회</b></div>
      <div class="card"><span>리프트 이용</span><b>8회</b></div>
      <div class="card"><span>총 하강고도</span><b>946 m</b></div>
      <div class="card"><span>평균 활주속도</span><b>26.0 km/h</b></div>
      <div class="card"><span>활주 시간</span><b>24분 47초</b></div>
      <div class="card"><span>리프트 시간</span><b>54분</b></div>
      <div class="card"><span>휴식/정지</span><b>18분</b></div>
      <div class="card"><span>최고 속도</span><b>${r.max}</b></div>
    </div>

    <div class="detail-section-head"><b>활주별 기록</b><small>활주를 누르면 세부 구간 보기</small></div>
    <div class="card snow-descents-card">
      ${snowDescents.map(snowDescentRow).join('')}
    </div>

    <div class="detail-section-head"><b>슬로프별 합계</b><small>같은 슬로프 자동 합산</small></div>
    <div class="card snow-list-card">
      ${snowSlopeStats.map((s,i)=>`<div class="snow-stat-row-static">
        <i class="snow-list-color-bar" style="background:${snowTypeColor('slope',s.name)}"></i>
        <div class="snow-stat-name"><b>${s.name}</b><span>${s.runs}회 · ${s.distance}</span></div>
        <div class="snow-stat-metric"><span>${s.avg}</span><small>최고 ${s.max}</small></div>
        <div class="snow-stat-vert">${s.vertical}</div>
      </div>`).join('')}
    </div>

    <div class="detail-section-head"><b>리프트 이용</b><small>이름 변경 제안은 별도 수정 요청에서 처리</small></div>
    <div class="card snow-list-card">
      ${snowLiftStats.map((x,i)=>`<div class="snow-lift-row2">
        <i class="snow-list-color-bar" style="background:${snowLiftRouteColor(snowLiftDisplayName(x,i))}"></i>
        <div class="snow-lift-name"><b>${escapeLoc(snowLiftDisplayName(x,i))}</b><small>${x.distance} · ${x.rides}회 · ${x.time}</small></div>
        <span>${x.rides}회</span>
        <span>${x.time}</span>
      </div>`).join('')}
    </div>

    <div class="grade-policy-note">활주 1회 안에 여러 슬로프·미확인·트리런 구간이 이어질 수 있습니다. 활주를 누르면 실제 지나간 순서대로 세부 구간과 지도를 확인할 수 있습니다.</div>`;
}

const SLEEP_RECORD_TOTAL_SEC=7*3600+25*60;
const SLEEP_RECORD_START_MIN=23*60+30;

function sleepClockFromOffset(sec){
  const totalMin=SLEEP_RECORD_START_MIN+Math.floor(sec/60);
  const m=((totalMin%1440)+1440)%1440;
  const hh=Math.floor(m/60),mm=m%60,ss=Math.floor(sec%60);
  return `${String(hh).padStart(2,'0')}:${String(mm).padStart(2,'0')}:${String(ss).padStart(2,'0')}`;
}
function sleepOffsetFromClock(clock){
  const p=String(clock).split(':').map(Number);
  if(p.length<2)return 0;
  let min=p[0]*60+p[1];
  if(min<SLEEP_RECORD_START_MIN)min+=1440;
  return Math.max(0,Math.min(SLEEP_RECORD_TOTAL_SEC,(min-SLEEP_RECORD_START_MIN)*60+(p[2]||0)));
}
function sleepDbAt(sec){
  const f=Math.max(0,Math.min(1,sec/SLEEP_RECORD_TOTAL_SEC));
  const pos=f*(sleepDbSeries.length-1);
  const i=Math.floor(pos),j=Math.min(sleepDbSeries.length-1,i+1),t=pos-i;
  return sleepDbSeries[i]+(sleepDbSeries[j]-sleepDbSeries[i])*t;
}
function sleepDbGraphMarkup(){
  const minDb=20,maxDb=60,span=maxDb-minDb;
  const values=sleepDbSeries;
  const xy=values.map((v,i)=>[
    7+(89*i/(values.length-1)),
    91-(76*(v-minDb)/span)
  ]);
  return `<div class="sleep-db-wrap">
    <div class="sleep-db-axis">
      <span>60</span><span>50</span><span>40</span><span>30</span><span>20</span>
      <b>dB</b>
    </div>
    <div class="sleep-db-graph sleep-db-overview">
      <div class="sleep-db-grid d60"></div><div class="sleep-db-grid d50"></div>
      <div class="sleep-db-grid d40"></div><div class="sleep-db-grid d30"></div><div class="sleep-db-grid d20"></div>
      ${xy.slice(0,-1).map((a,i)=>{
        const b=xy[i+1];
        return `<i class="sleep-db-line" style="${lineSegmentStyle(a[0],a[1],b[0],b[1],'#657d93',3)}"></i>`;
      }).join('')}
      ${sleepCandidates.filter(c=>!sleepCandidateDeleted.includes(c.id)).map(c=>{
        const sec=sleepOffsetFromClock(c.time);
        const left=7+89*(sec/SLEEP_RECORD_TOTAL_SEC);
        const db=parseFloat(c.db)||sleepDbAt(sec);
        const top=91-(76*(db-minDb)/span);
        return `<span class="sleep-db-candidate-static" style="left:${left}%;top:${top}%"></span>`;
      }).join('')}
    </div>
  </div>
  <div class="sleep-db-time-axis"><span>23:30</span><span>01:20</span><span>03:10</span><span>05:00</span><span>06:55</span></div>
  <div class="sleep-db-guide">전체 수면 시간의 데시벨 흐름입니다. 이 그래프에서는 재생 위치를 이동하지 않습니다.</div>`;
}

function seekSleepPlayback(sec,autoplay=true){
  sleepPlaybackSec=Math.max(0,Math.min(SLEEP_RECORD_TOTAL_SEC,sec));
  if(autoplay)sleepGraphPlaying=true;
  sleepCandidatePlaying=null;
  updateSleepPlaybackUi();
  if(sleepGraphPlaying)startSleepRecordPlaybackTimer();
}
function updateSleepPlaybackUi(){
  const cursor=document.getElementById('sleepDbCursor');
  if(cursor)cursor.style.left=(7+89*(sleepPlaybackSec/SLEEP_RECORD_TOTAL_SEC))+'%';
  const time=document.getElementById('sleepGraphTime');
  if(time)time.textContent=sleepClockFromOffset(sleepPlaybackSec);
  const db=document.getElementById('sleepGraphDb');
  if(db)db.textContent=sleepDbAt(sleepPlaybackSec).toFixed(0)+' dB';
  const play=document.getElementById('sleepGraphPlay');
  if(play)play.textContent=sleepGraphPlaying?'Ⅱ':'▶';
  const now=document.querySelector('.sleep-graph-now small');
  if(now)now.textContent=sleepGraphPlaying?'재생 중':'재생 위치';
}
function startSleepRecordPlaybackTimer(){
  stopSleepRecordPlaybackTimer();
  if(!sleepGraphPlaying)return;
  sleepRecordAudioTimer=setInterval(()=>{
    if(!sleepGraphPlaying)return;
    sleepPlaybackSec+=1;
    if(sleepPlaybackSec>=SLEEP_RECORD_TOTAL_SEC){
      sleepPlaybackSec=SLEEP_RECORD_TOTAL_SEC;
      sleepGraphPlaying=false;
      stopSleepRecordPlaybackTimer();
    }
    updateSleepPlaybackUi();
  },1000);
}
function stopSleepRecordPlaybackTimer(){
  if(sleepRecordAudioTimer){clearInterval(sleepRecordAudioTimer);sleepRecordAudioTimer=null}
}
function bindSleepDbGraph(){
  const touch=document.getElementById('sleepDbTouch');
  const graph=document.getElementById('sleepDbGraph');
  if(touch&&graph){
    touch.addEventListener('click',e=>{
      const rect=graph.getBoundingClientRect();
      const padLeft=rect.width*0.07,padRight=rect.width*0.04;
      const usable=Math.max(1,rect.width-padLeft-padRight);
      const x=Math.max(0,Math.min(usable,e.clientX-rect.left-padLeft));
      const f=x/usable;
      seekSleepPlayback(f*SLEEP_RECORD_TOTAL_SEC,true);
    });
  }
  document.querySelectorAll('[data-db-candidate]').forEach(b=>b.onclick=e=>{
    e.stopPropagation();
    const c=sleepCandidates.find(x=>x.id===b.dataset.dbCandidate);
    if(!c)return;
    sleepCandidatePlaying=c.id;
    sleepPlaybackSec=sleepOffsetFromClock(c.time);
    sleepGraphPlaying=true;
    updateSleepPlaybackUi();
    startSleepRecordPlaybackTimer();
  });
  const play=document.getElementById('sleepGraphPlay');
  if(play)play.onclick=()=>{
    sleepGraphPlaying=!sleepGraphPlaying;
    if(sleepGraphPlaying)startSleepRecordPlaybackTimer();
    else stopSleepRecordPlaybackTimer();
    updateSleepPlaybackUi();
  };
}


function sleepCandidateDurationSec(c){
  return Math.max(1,parseInt(c.duration,10)||10);
}
function sleepCandidateWaveValues(c){
  const seed=parseInt(c.id.replace(/\D/g,''),10)||1;
  const n=44;
  const vals=[];
  for(let i=0;i<n;i++){
    const x=i/(n-1);
    const a=Math.sin((i+seed)*1.83)*0.28+Math.sin((i+seed*3)*0.71)*0.21;
    const pulse=(Math.sin((x*3.5+seed*.17)*Math.PI)**2)*0.48;
    const centerBoost=0.35+0.65*Math.sin(Math.PI*x);
    vals.push(Math.max(.10,Math.min(1,(.24+Math.abs(a)+pulse)*centerBoost)));
  }
  return vals;
}
function sleepCandidateProgressSec(id){
  return Math.max(0,Number(sleepCandidateProgress[id]||0));
}
function sleepCandidateWaveMarkup(c){
  const vals=sleepCandidateWaveValues(c);
  const dur=sleepCandidateDurationSec(c);
  const progress=Math.min(dur,sleepCandidateProgressSec(c.id));
  const pct=(progress/dur)*100;
  return `<div class="sleep-wave-shell">
    <div class="sleep-wave-db"><span>${c.db}</span></div>
    <div class="sleep-waveform" data-sleep-wave="${c.id}" aria-label="${c.time} 음성 파형">
      <div class="sleep-wave-mid"></div>
      ${vals.map(v=>`<i style="height:${Math.round(8+v*38)}px"></i>`).join('')}
      <div class="sleep-wave-cursor" data-wave-cursor="${c.id}" style="left:${pct}%"><b></b></div>
    </div>
  </div>
  <div class="sleep-wave-time">
    <span data-wave-time="${c.id}">${formatCandidateTime(progress)}</span>
    <span>${formatCandidateTime(dur)}</span>
  </div>`;
}
function formatCandidateTime(sec){
  sec=Math.max(0,sec);
  const s=Math.floor(sec);
  const tenth=Math.floor((sec-s)*10);
  return `00:${String(s).padStart(2,'0')}.${tenth}`;
}
function updateCandidateWaveUi(id){
  const c=sleepCandidates.find(x=>x.id===id);
  if(!c)return;
  const dur=sleepCandidateDurationSec(c);
  const progress=Math.min(dur,sleepCandidateProgressSec(id));
  const cursor=document.querySelector(`[data-wave-cursor="${id}"]`);
  if(cursor)cursor.style.left=((progress/dur)*100)+'%';
  const time=document.querySelector(`[data-wave-time="${id}"]`);
  if(time)time.textContent=formatCandidateTime(progress);
  const play=document.querySelector(`[data-sleep-play="${id}"]`);
  if(play)play.textContent=sleepCandidatePlaying===id?'Ⅱ':'▶';
}
function stopSleepCandidateAudioTimer(){
  if(sleepCandidateAudioTimer){clearInterval(sleepCandidateAudioTimer);sleepCandidateAudioTimer=null}
}
function startSleepCandidateAudioTimer(){
  stopSleepCandidateAudioTimer();
  if(!sleepCandidatePlaying)return;
  sleepCandidateAudioTimer=setInterval(()=>{
    const id=sleepCandidatePlaying;
    const c=sleepCandidates.find(x=>x.id===id);
    if(!c){stopSleepCandidateAudioTimer();return}
    const dur=sleepCandidateDurationSec(c);
    sleepCandidateProgress[id]=sleepCandidateProgressSec(id)+0.1;
    if(sleepCandidateProgress[id]>=dur){
      sleepCandidateProgress[id]=dur;
      sleepCandidatePlaying=null;
      stopSleepCandidateAudioTimer();
    }
    updateCandidateWaveUi(id);
  },100);
}
function seekCandidateAudio(id,sec,play=true){
  const c=sleepCandidates.find(x=>x.id===id);
  if(!c)return;
  const dur=sleepCandidateDurationSec(c);
  sleepCandidateProgress[id]=Math.max(0,Math.min(dur,sec));
  if(play)sleepCandidatePlaying=id;
  updateCandidateWaveUi(id);
  if(play)startSleepCandidateAudioTimer();
}
function bindSleepCandidateWaveforms(){
  document.querySelectorAll('[data-sleep-wave]').forEach(w=>w.onclick=e=>{
    const id=w.dataset.sleepWave;
    const c=sleepCandidates.find(x=>x.id===id);
    if(!c)return;
    const rect=w.getBoundingClientRect();
    const f=Math.max(0,Math.min(1,(e.clientX-rect.left)/Math.max(1,rect.width)));
    seekCandidateAudio(id,f*sleepCandidateDurationSec(c),true);
  });
}

function sleepCandidateRow(c){
  if(sleepCandidateDeleted.includes(c.id))return '';
  const falsePositive=sleepFalsePositiveIds.includes(c.id);
  const uploaded=sleepUploadedIds.includes(c.id);
  const playing=sleepCandidatePlaying===c.id;
  return `<div class="sleep-candidate-row2 ${falsePositive?'false-positive':''}">
    <div class="sleep-candidate-head2">
      <button class="sleep-play-mini" data-sleep-play="${c.id}">${playing?'Ⅱ':'▶'}</button>
      <div class="sleep-candidate-title2">
        <b>${c.time} · ${c.duration}</b>
        <span>코골이 가능성 ${c.score} · 최대 ${c.db}${falsePositive?' · 코골이 아님':''}</span>
      </div>
      <button class="sleep-more-btn" data-sleep-false="${c.id}">${falsePositive?'취소':'아님'}</button>
      <button class="sleep-more-btn upload ${uploaded?'done':''}" data-sleep-upload="${c.id}" ${uploaded?'disabled':''}>${uploaded?'전송됨':'업로드'}</button>
      <button class="sleep-more-btn delete" data-sleep-delete="${c.id}">삭제</button>
    </div>
    ${sleepCandidateWaveMarkup(c)}
  </div>`;
}
function sleepCandidateListMarkup(){
  const visible=sleepCandidates.filter(c=>!sleepCandidateDeleted.includes(c.id));
  return `<div class="detail-section-head"><b>코골이 후보</b><small>${visible.length}개 음성 구간</small></div>
    <div class="card sleep-candidate-card">${visible.map(sleepCandidateRow).join('')||`<div class="sleep-none">남아 있는 코골이 후보가 없습니다.</div>`}</div>
    <div class="sleep-upload-note"><b>분석 개선용 업로드</b><br>사용자가 직접 들어보고 <b>코골이가 아니라고 판단한 구간</b>만 선택해서 업로드할 수 있습니다. 업로드 전 한 번 더 확인하며, 이 HTML에서는 실제 음성 전송 없이 흐름만 확인합니다.</div>`;
}
function bindSleepCandidates(){
  bindSleepCandidateWaveforms();
  document.querySelectorAll('[data-sleep-play]').forEach(b=>b.onclick=()=>{
    const id=b.dataset.sleepPlay;
    const c=sleepCandidates.find(x=>x.id===id);
    if(!c)return;
    const dur=sleepCandidateDurationSec(c);
    if(sleepCandidatePlaying===id){
      sleepCandidatePlaying=null;
      stopSleepCandidateAudioTimer();
      updateCandidateWaveUi(id);
    }else{
      if(sleepCandidateProgressSec(id)>=dur)sleepCandidateProgress[id]=0;
      sleepCandidatePlaying=id;
      startSleepCandidateAudioTimer();
      updateCandidateWaveUi(id);
    }
  });
  document.querySelectorAll('[data-sleep-false]').forEach(b=>b.onclick=()=>{
    const id=b.dataset.sleepFalse;
    if(sleepFalsePositiveIds.includes(id))sleepFalsePositiveIds=sleepFalsePositiveIds.filter(x=>x!==id);
    else sleepFalsePositiveIds.push(id);
    renderRecordDetail();
  });
  document.querySelectorAll('[data-sleep-upload]').forEach(b=>b.onclick=()=>{
    const id=b.dataset.sleepUpload;
    if(!sleepFalsePositiveIds.includes(id)){say('먼저 들어보고 코골이 아님으로 표시해 주세요.');return}
    confirmSleepUpload(id);
  });
  document.querySelectorAll('[data-sleep-delete]').forEach(b=>b.onclick=()=>confirmSleepCandidateDelete(b.dataset.sleepDelete));
  if(sleepCandidatePlaying)startSleepCandidateAudioTimer();
}
function confirmSleepUpload(id){
  const c=sleepCandidates.find(x=>x.id===id);
  moveOverlay.classList.add('show');
  moveOverlay.innerHTML=`<div class="move-sheet"><div class="move-sheet-handle"></div>
    <h3>이 음성을 업로드할까요?</h3>
    <p>${c.time}의 ${c.duration} 구간입니다. 코골이 오탐 분석 개선용으로 사용자가 선택한 이 구간만 전송합니다.</p>
    <div class="move-sheet-actions"><button id="sleepUploadCancel" class="move-sheet-cancel">취소</button><button id="sleepUploadConfirm" class="move-sheet-stop" style="background:var(--primary);color:#fff">선택 구간 업로드</button></div>
  </div>`;
  document.getElementById('sleepUploadCancel').onclick=closeMoveOverlay;
  document.getElementById('sleepUploadConfirm').onclick=()=>{
    if(!sleepUploadedIds.includes(id))sleepUploadedIds.push(id);
    closeMoveOverlay();say('선택한 오탐 구간을 업로드한 것으로 처리했습니다.');renderRecordDetail();
  };
}
function confirmSleepCandidateDelete(id){
  const c=sleepCandidates.find(x=>x.id===id);
  moveOverlay.classList.add('show');
  moveOverlay.innerHTML=`<div class="move-sheet"><div class="move-sheet-handle"></div>
    <h3>이 후보 음성을 삭제할까요?</h3>
    <p>${c.time} · ${c.duration} 구간입니다. 삭제하면 이 기록에서 다시 재생할 수 없습니다.</p>
    <div class="move-sheet-actions"><button id="sleepDeleteCancel" class="move-sheet-cancel">취소</button><button id="sleepDeleteConfirm" class="move-sheet-stop">삭제</button></div>
  </div>`;
  document.getElementById('sleepDeleteCancel').onclick=closeMoveOverlay;
  document.getElementById('sleepDeleteConfirm').onclick=()=>{
    if(!sleepCandidateDeleted.includes(id))sleepCandidateDeleted.push(id);
    sleepCandidatePlaying=null;closeMoveOverlay();say('후보 음성을 삭제했습니다.');renderRecordDetail();
  };
}

function recordStatsMarkup(r){
  if(r.mode==='run'){
    return `<div class="detail-stat-grid">
      <div class="card"><span>거리</span><b>${r.distance}</b></div><div class="card"><span>시간</span><b>${r.duration}</b></div>
      <div class="card"><span>평균 페이스</span><b>${r.avg}</b></div><div class="card"><span>최고 속도</span><b>${r.max}</b></div>
      <div class="card"><span>칼로리</span><b>${r.cal}</b></div><div class="card"><span>누적 상승</span><b>${r.gain}</b></div>
    </div>`;
  }
  return `<div class="detail-stat-grid">
    <div class="card"><span>거리</span><b>${r.distance}</b></div><div class="card"><span>시간</span><b>${r.duration}</b></div>
    <div class="card"><span>평균 속도</span><b>${r.avg}</b></div><div class="card"><span>최고 속도</span><b>${r.max}</b></div>
    <div class="card"><span>칼로리</span><b>${r.cal}</b></div><div class="card"><span>누적 상승</span><b>${r.gain}</b></div>
  </div>`;
}


function snowTypeLabel(type){
  return type==='tree'?'트리런':type==='unknown'?'미확인':'슬로프';
}
const snowSlopeColorMap={
  'A 슬로프':'#4e9fda',
  'B 슬로프':'#57b783',
  'C 슬로프':'#e68a58',
  'D 슬로프':'#d66fa4',
  'E 슬로프':'#6e79d8',
  'F 슬로프':'#d2a542'
};
function snowTypeColor(type,name=''){
  if(type==='tree')return '#8c65c7';
  if(type==='unknown')return '#9aa5ad';
  return snowSlopeColorMap[name]||'#4e9fda';
}
function snowSegmentColor(seg){
  return snowTypeColor(seg.type,snowRunDisplayName(seg));
}
function snowDescentDetailMap(descent){
  const segments=descent.segments;
  const pts=recordRouteXY.slice(0,segments.length+1);
  return `<div class="detail-map snow-run-detail-map">
    <span class="detail-map-road a"></span><span class="detail-map-road b"></span><span class="detail-map-road c"></span>
    ${segments.map((seg,i)=>{
      const a=pts[i],b=pts[i+1];
      const color=snowSegmentColor(seg);
      return `<span class="snow-detail-map-seg active" style="${lineSegmentStyle(a[0],a[1],b[0],b[1],color,8)}"></span>`;
    }).join('')}
    <span class="map-start">S</span><span class="map-end">E</span>
  </div>
  <div class="snow-detail-map-legend">
    <span><i style="background:#4e9fda"></i>A</span>
    <span><i style="background:#57b783"></i>B</span>
    <span><i style="background:#e68a58"></i>C</span>
    <span><i style="background:#d66fa4"></i>D</span>
    <span><i style="background:#9aa5ad"></i>미확인</span>
    <span><i style="background:#8c65c7"></i>트리런</span>
  </div>`;
}
function snowSegmentDetailRow(seg,index){
  const type=snowTypeLabel(seg.type);
  return `<div class="snow-segment-detail-row">
    <i class="snow-segment-type" style="background:${snowSegmentColor(seg)}"></i>
    <div class="snow-segment-main">
      <div class="snow-segment-name"><b>${escapeLoc(snowRunDisplayName(seg))}</b><span>${type}</span></div>
      <div class="snow-segment-time">${seg.start} → ${seg.end} · ${seg.duration}</div>
      <div class="snow-segment-metrics">
        <span>평균 <b>${seg.avg}</b></span>
        <span>최고 <b>${seg.max}</b></span>
        <span>${seg.distance}</span>
      </div>
    </div>
    <button class="snow-segment-correction" data-segment-correction="${seg.id}">수정하기</button>
  </div>`;
}
function snowRunDetailTop(){
  return `<div class="move-sticky"><div class="move-header-row">
    <button id="snowDetailTopBack" class="move-back-asset-btn">
      <img class="move-back-asset" src="${A}back-ready.png" alt="뒤로가기">
    </button>
    <div class="snow-run-top-title">활주 목록</div>
  </div></div>`;
}

function snowRunDetailMarkup(descent){
  return `
    <div class="snow-run-detail-page">
      <div class="card snow-descent-detail-head">
        <div class="snow-descent-detail-title">
          <small>활주 상세</small>
          <b>${descent.label}</b>
        </div>
        <div class="snow-descent-detail-time">${descent.start} → ${descent.end} · ${descent.duration}</div>
        <div class="snow-descent-detail-metrics">
          <span>평균 <b>${descent.avg}</b></span>
          <span>최고 <b>${descent.max}</b></span>
          <span>${descent.distance}</span>
        </div>
      </div>

      <div class="detail-section-head"><b>활주 지도</b><small>구간 종류별 색상</small></div>
      <div class="card detail-map-card">
        ${snowDescentDetailMap(descent)}
      </div>

      <div class="detail-section-head"><b>구간별 기록</b><small>실제 지나간 순서</small></div>
      <div class="card snow-segment-list">
        ${descent.segments.map(snowSegmentDetailRow).join('')}
      </div>

      <div class="grade-policy-note">수정은 각 세부 구간별로 합니다. 변경할 슬로프 이름을 직접 입력하거나, 트리런 구간이면 '트리런'이라고 입력해서 확정합니다.</div>
    </div>`;
}
function openSnowCorrection(segmentId){
  const run=snowSegmentById(segmentId);
  const currentName=run.type==='tree'?'트리런':snowRunDisplayName(run)==='미확인'?'':snowRunDisplayName(run);

  moveOverlay.classList.add('show');
  moveOverlay.innerHTML=`<div class="move-sheet snow-correction-sheet">
    <div class="move-sheet-handle"></div>
    <h3>구간 수정하기</h3>
    <p>변경할 슬로프 이름을 입력하세요. 트리런이면 <b>트리런</b>이라고 입력하세요.</p>

    <div class="snow-simple-correction">
      <label>변경 내용</label>
      <input id="snowCorrectionName" class="alarm-input" maxlength="40"
        value="${escapeLoc(currentName)}"
        placeholder="예: A 슬로프 또는 트리런">
    </div>

    <div class="location-note">
      ${run.start} → ${run.end} · ${run.duration}<br>
      미확인으로 되돌리는 수정은 없으며, 슬로프 이름 또는 트리런으로 확정해서 보냅니다.
    </div>

    <div class="move-sheet-actions">
      <button id="snowCorrectionCancel" class="move-sheet-cancel">취소</button>
      <button id="snowCorrectionSend" class="move-sheet-stop" style="background:var(--primary);color:#fff">수정 요청 보내기</button>
    </div>
  </div>`;

  const input=document.getElementById('snowCorrectionName');
  setTimeout(()=>input&&input.focus(),50);

  document.getElementById('snowCorrectionCancel').onclick=closeMoveOverlay;
  document.getElementById('snowCorrectionSend').onclick=()=>{
    const value=input.value.trim();
    if(!value){
      say('변경할 슬로프 이름 또는 트리런을 입력해 주세요.');
      return;
    }

    if(value.replace(/\s/g,'')==='트리런'){
      run.type='tree';
      snowLocalNames[run.id]='트리런';
    }else{
      run.type='slope';
      snowLocalNames[run.id]=value;
    }

    if(!snowMapSubmissionIds.includes(run.id))snowMapSubmissionIds.push(run.id);
    closeMoveOverlay();
    say('선택한 구간의 수정 요청을 보냈습니다.');
    renderRecordDetail();
  };
}

function openSnowNameEditor(runId){
  const run=snowRunById(runId);
  const current=snowRunDisplayName(run);
  moveOverlay.classList.add('show');
  moveOverlay.innerHTML=`<div class="move-sheet">
    <div class="move-sheet-handle"></div>
    <h3>${run.type==='unknown'?'미확인 구간 이름 지정':'슬로프 이름 수정'}</h3>
    <p>내 기록에서 사용할 이름을 직접 입력할 수 있습니다. 보내지 않으면 내 기록에만 저장됩니다.</p>
    <input id="snowLocalNameInput" class="alarm-input" maxlength="40" value="${escapeLoc(current==='미확인'?'':current)}" placeholder="예: A 슬로프">
    <div class="move-sheet-actions">
      <button id="snowNameCancel" class="move-sheet-cancel">취소</button>
      <button id="snowNameSave" class="move-sheet-stop" style="background:var(--primary);color:#fff">내 기록에만 저장</button>
    </div>
    <button id="snowNameSaveSend" class="location-start" style="margin-top:8px">저장하고 지도 수정으로 보내기</button>
  </div>`;
  document.getElementById('snowNameCancel').onclick=closeMoveOverlay;
  document.getElementById('snowNameSave').onclick=()=>{
    const v=document.getElementById('snowLocalNameInput').value.trim();
    if(!v){say('이름을 입력해 주세요.');return}
    snowLocalNames[runId]=v;closeMoveOverlay();say('내 기록의 이름을 수정했습니다.');renderRecordDetail();
  };
  document.getElementById('snowNameSaveSend').onclick=()=>{
    const v=document.getElementById('snowLocalNameInput').value.trim();
    if(!v){say('이름을 입력해 주세요.');return}
    snowLocalNames[runId]=v;closeMoveOverlay();confirmSnowMapSubmit(runId,'name');
  };
}
function markSnowTreeRun(runId){
  const run=snowRunById(runId);
  snowLocalNames[runId]='트리런';
  run.type='tree';
  say('내 기록에서 트리런으로 표시했습니다.');
  renderRecordDetail();
}
function confirmSnowMapSubmit(runId,mode='segment'){
  const run=snowRunById(runId);
  const name=snowRunDisplayName(run);
  moveOverlay.classList.add('show');
  moveOverlay.innerHTML=`<div class="move-sheet">
    <div class="move-sheet-handle"></div>
    <h3>지도 수정으로 보낼까요?</h3>
    <p><b>${escapeLoc(name)}</b> 구간 주변의 선택된 경로와 제안한 이름/유형만 보냅니다. 전체 하루 기록이나 다른 위치 이력, 개인 정보는 보내지 않습니다.</p>
    <div class="snow-submit-summary">
      <span>종류</span><b>${run.type==='tree'?'트리런':run.type==='unknown'?'미확인 구간':'슬로프'}</b>
      <span>구간</span><b>${run.distance}</b>
      <span>처리</span><b>검토 후 다음 지도 버전 후보</b>
    </div>
    <div class="move-sheet-actions">
      <button id="snowSubmitCancel" class="move-sheet-cancel">취소</button>
      <button id="snowSubmitConfirm" class="move-sheet-stop" style="background:var(--primary);color:#fff">이 구간만 보내기</button>
    </div>
  </div>`;
  document.getElementById('snowSubmitCancel').onclick=closeMoveOverlay;
  document.getElementById('snowSubmitConfirm').onclick=()=>{
    if(!snowMapSubmissionIds.includes(runId))snowMapSubmissionIds.push(runId);
    closeMoveOverlay();say('선택한 구간을 지도 수정 후보로 보냈습니다.');renderRecordDetail();
  };
}
function openLiftNameEditor(index){
  const lift=snowLiftStats[index];
  const current=snowLiftDisplayName(lift,index);
  moveOverlay.classList.add('show');
  moveOverlay.innerHTML=`<div class="move-sheet">
    <div class="move-sheet-handle"></div>
    <h3>리프트 이름 수정</h3>
    <p>내 기록의 리프트 이름만 직접 바꾸거나, 지도 수정으로 보낼 수 있습니다.</p>
    <input id="snowLiftNameInput" class="alarm-input" maxlength="40" value="${escapeLoc(current)}">
    <div class="move-sheet-actions">
      <button id="liftNameCancel" class="move-sheet-cancel">취소</button>
      <button id="liftNameSave" class="move-sheet-stop" style="background:var(--primary);color:#fff">내 기록에만 저장</button>
    </div>
  </div>`;
  document.getElementById('liftNameCancel').onclick=closeMoveOverlay;
  document.getElementById('liftNameSave').onclick=()=>{
    const v=document.getElementById('snowLiftNameInput').value.trim();
    if(!v){say('이름을 입력해 주세요.');return}
    snowLiftLocalNames[index]=v;closeMoveOverlay();say('내 기록의 리프트 이름을 수정했습니다.');renderRecordDetail();
  };
}
function confirmLiftMapSubmit(index){
  const lift=snowLiftStats[index];
  moveOverlay.classList.add('show');
  moveOverlay.innerHTML=`<div class="move-sheet">
    <div class="move-sheet-handle"></div>
    <h3>리프트 지도 수정을 보낼까요?</h3>
    <p><b>${escapeLoc(snowLiftDisplayName(lift,index))}</b>의 이름 제안과 해당 리프트 근처 구간만 지도 수정 후보로 보냅니다.</p>
    <div class="move-sheet-actions">
      <button id="liftSubmitCancel" class="move-sheet-cancel">취소</button>
      <button id="liftSubmitConfirm" class="move-sheet-stop" style="background:var(--primary);color:#fff">이 리프트만 보내기</button>
    </div>
  </div>`;
  document.getElementById('liftSubmitCancel').onclick=closeMoveOverlay;
  document.getElementById('liftSubmitConfirm').onclick=()=>{
    closeMoveOverlay();say('리프트 수정 제안을 보냈습니다.');
  };
}
function bindSnowRecordActions(){
  document.querySelectorAll('[data-snow-descent]').forEach(b=>b.onclick=()=>{
    snowMainScrollTop=screen.scrollTop||0;
    snowSelectedDescentId=b.dataset.snowDescent;
    snowRunDetailOpen=true;
    renderRecordDetail();
    screen.scrollTop=0;
  });

  const topBack=document.getElementById('snowDetailTopBack');
  if(topBack)topBack.onclick=()=>{
    snowRunDetailOpen=false;
    renderRecordDetail();
    requestAnimationFrame(()=>{screen.scrollTop=snowMainScrollTop||0;});
  };

  document.querySelectorAll('[data-segment-correction]').forEach(b=>b.onclick=()=>{
    openSnowCorrection(b.dataset.segmentCorrection);
  });
}
function renderMovementRecordDetail(r){
  const info=selectedGradeInfo(r);
  if(r.mode==='snow'&&snowRunDetailOpen){
    const descent=snowDescentById(snowSelectedDescentId);
    screen.innerHTML=`
      ${snowRunDetailTop()}
      ${snowRunDetailMarkup(descent)}
    `;
    bindSnowRecordActions();
    return;
  }
  screen.innerHTML=`
    ${recordDetailHeader(r)}
    <div class="record-detail-summary">
      <div><b>${r.title}</b><small>${r.date}</small></div>
      <span>${r.mode==='bike'?'자전거':r.mode==='snow'?'Snow':'달리기'}</span>
    </div>
    ${recordStatsMarkup(r)}
    ${r.kind==='move'?kmSplitMarkup(r):''}
    ${r.mode==='bike'?bikeSpeedGraphMarkup():''}
    ${r.mode==='snow'?snowExtendedMarkup(r):''}

    <div class="detail-section-head"><b>전체 경로</b><small>${r.mode==='snow'?'활주 구간별 색상':'경사도 색상 표시'}</small></div>
    <div class="card detail-map-card">
      ${routeMarkup(r)}
      ${r.mode==='snow'?'':gradeLegend()}
    </div>

    ${r.mode==='snow'?'':`
      <div class="detail-section-head"><b>고도</b><small>지도와 동일한 경사 색상</small></div>
      <div class="card detail-elev-card">${elevationMarkup(r)}${gradeLegend()}</div>
    `}

    ${r.mode==='snow'?'':`<div class="card grade-selected-card" style="--grade-accent:${info.color}">
      <div class="grade-selected-color"></div>
      <div class="grade-selected-copy">
        <small>선택 구간</small>
        <b>${(info.startM/1000).toFixed(2)} ~ ${(info.endM/1000).toFixed(2)} km · ${info.g>0?'+':''}${info.g.toFixed(1)}%</b>
        <span>${info.label} · 고도 변화 ${info.dz>=0?'+':''}${info.dz.toFixed(1)} m</span>
      </div>
    </div>`}

    ${r.mode==='snow'?'':`<div class="card grade-method-card">
      <div><span>경사 분석 거리</span><b>${r.window}m 이동창</b></div>
      <div><span>색상 갱신 간격</span><b>약 ${r.refresh}m</b></div>
      <div><span>고도 처리</span><b>노이즈 평활화 후 평균 경사</b></div>
      <div><span>경사 색상</span><b>파랑 · 초록 · 빨강 연속 보간</b></div>
    </div>`}

    <div class="grade-policy-note">${
      r.mode==='bike'
        ?'자전거는 이동 속도가 빨라 200m 이동창으로 경사를 계산하고 약 50m마다 색상을 갱신합니다.'
        :r.mode==='snow'
          ?'Snow는 고도 그래프를 표시하지 않고, 지도에서는 실제 활주 순서의 슬로프·미확인·트리런 구간을 서로 다른 색으로 구분합니다.'
          :'짧은 언덕과 내리막을 살리기 위해 100m 이동창으로 경사를 계산하고 약 25m마다 색상을 갱신합니다.'
    } GPS 고도값은 먼저 부드럽게 보정해 순간적인 고도 튐이 경사 색상으로 과장되지 않도록 합니다.</div>

    <button id="deleteRecord" class="record-delete-btn">이 기록 삭제</button>`;
  bindRecordDetail(r);
  if(r.mode==='snow')bindSnowRecordActions();
}
function renderSleepRecordDetail(r){
  stopSleepRecordPlaybackTimer();
  screen.innerHTML=`
    ${recordDetailHeader(r)}
    <div class="record-detail-summary">
      <div><b>수면 기록</b><small>${r.date}</small></div><span>수면</span>
    </div>
    <div class="detail-stat-grid">
      <div class="card"><span>수면 시간</span><b>${r.sleepTotal}</b></div>
      <div class="card"><span>코골이 후보</span><b>${sleepCandidates.length-sleepCandidateDeleted.length}개</b></div>
      <div class="card"><span>평균 소리</span><b>${r.soundAvg}</b></div>
      <div class="card"><span>최대 소리</span><b>${r.soundMax}</b></div>
    </div>

    <div class="detail-section-head"><b>데시벨 그래프</b><small>터치한 위치부터 음성 재생</small></div>
    <div class="card sleep-db-card">${sleepDbGraphMarkup()}</div>

    ${sleepCandidateListMarkup()}

    <div class="card sleep-summary-card">
      <div><span>코골이 아님으로 표시</span><b>${sleepFalsePositiveIds.filter(x=>!sleepCandidateDeleted.includes(x)).length}개</b></div>
      <div><span>분석 개선용 업로드</span><b>${sleepUploadedIds.filter(x=>!sleepCandidateDeleted.includes(x)).length}개</b></div>
      <div><span>삭제된 후보</span><b>${sleepCandidateDeleted.length}개</b></div>
    </div>

    <div class="grade-policy-note">전체 데시벨 그래프는 밤 전체 흐름 확인용입니다. 실제 재생 위치 이동은 각 코골이 후보의 개별 음성 파형에서 합니다.</div>
    <button id="deleteRecord" class="record-delete-btn">이 수면 기록 전체 삭제</button>`;
  bindRecordDetail(r);
  bindSleepCandidates();
}
function bindRecordDetail(r){
  document.getElementById('recordDetailBack').onclick=()=>{
    stopSleepRecordPlaybackTimer();
    stopSleepCandidateAudioTimer();
    sleepGraphPlaying=false;
    sleepCandidatePlaying=null;
    snowRunDetailOpen=false;
    recordDetailId=null;view='main';tab='records';render();
  };
  document.querySelectorAll('[data-grade-seg]').forEach(x=>x.onclick=()=>{
    recordSelectedSegment=+x.dataset.gradeSeg;
    renderRecordDetail();
  });
  const del=document.getElementById('deleteRecord');
  if(del)del.onclick=()=>confirmRecordDelete(r);
}
function confirmRecordDelete(r){
  moveOverlay.classList.add('show');
  moveOverlay.innerHTML=`<div class="move-sheet"><div class="move-sheet-handle"></div>
    <h3>이 기록을 삭제할까요?</h3>
    <p>${r.title} 기록은 삭제 후 복구할 수 없습니다.</p>
    <div class="move-sheet-actions">
      <button id="recordDeleteCancel" class="move-sheet-cancel">취소</button>
      <button id="recordDeleteConfirm" class="move-sheet-stop">삭제</button>
    </div></div>`;
  document.getElementById('recordDeleteCancel').onclick=closeMoveOverlay;
  document.getElementById('recordDeleteConfirm').onclick=()=>{
    deletedRecordIds.push(r.id);closeMoveOverlay();recordDetailId=null;view='main';tab='records';say('기록을 삭제했습니다.');render();
  };
}
function renderRecordDetail(){
  const r=recordSamples[recordDetailId]||recordSamples.run1;
  setFocusMode(false);
  if(r.kind==='sleep')renderSleepRecordDetail(r);
  else renderMovementRecordDetail(r);
}


const alarmRingtones=[
  {id:'basic',category:'기본',name:'Morning Bell',desc:'또렷하고 무난한 기본 알람',icon:'🔔'},
  {id:'soft',category:'조용하고 부드러운',name:'Soft Dawn',desc:'부드럽게 시작해서 천천히 깨우는 느낌',icon:'🌙'},
  {id:'beautiful',category:'아름다운',name:'Crystal Garden',desc:'맑고 잔잔한 멜로디 중심',icon:'✨'},
  {id:'fresh',category:'상쾌하고 활기찬',name:'Fresh Start',desc:'가볍고 기분 좋게 시작하는 아침 분위기',icon:'☀️'},
  {id:'loud',category:'매우 시끄러운',name:'Power Alarm',desc:'반드시 깨야 할 때 사용하는 강한 알람',icon:'⚡'}
];
let ringtonePickerOpen=false;
function ringtoneById(id){return alarmRingtones.find(x=>x.id===id)||alarmRingtones[0]}

let alarmSeq=3;
let alarmView='list';
let editingAlarmId=null;
let alarmDraft=null;
let ringingAlarmId=null;
let shakeProgress=0;
let alarms=[
  {
    id:1,time:'06:30',label:'기상',days:['월','화','수','목','금'],enabled:true,
    method:'sound',sound:'Morning Bell',ringtoneId:'basic',ttsText:'좋은 아침입니다. 일어날 시간이에요.',
    gradual:true,vibration:true,snoozeMin:10,snoozeCount:3,
    shakeEnabled:true,shakeCount:5,shakeStrength:'약하게',skipNext:false
  },
  {
    id:2,time:'08:10',label:'주말 알람',days:['토','일'],enabled:false,
    method:'tts',sound:'Morning Bell',ringtoneId:'basic',ttsText:'주말 아침입니다. 천천히 일어나세요.',
    gradual:false,vibration:true,snoozeMin:5,snoozeCount:3,
    shakeEnabled:false,shakeCount:3,shakeStrength:'약하게',skipNext:false
  }
];

function dayText(days){
  const d=[...days];
  if(d.length===7)return '매일';
  if(d.join(',')==='월,화,수,목,금')return '평일';
  if(d.join(',')==='토,일')return '주말';
  return d.length?d.join(' · '):'한 번';
}
function methodText(a){return a.method==='tts'?'텍스트 읽기':'알람 소리'}
function nextAlarmText(a){
  if(!a.enabled)return '꺼짐';
  if(a.skipNext)return '다음 1회 건너뜀';
  if(a.days.length===0)return '오늘 · '+a.time;
  return (a.days.join(',')==='토,일'?'토요일':'내일')+' · '+a.time;
}
function activeAlarmForNext(){
  return alarms.filter(a=>a.enabled&&!a.skipNext).sort((a,b)=>a.time.localeCompare(b.time))[0]||null;
}
function alarmHeader(label='알람',showBack=false){
  return `<div class="move-sticky"><div class="move-header-row">
    ${showBack?`<button id="alarmBack" class="move-back-asset-btn"><img class="move-back-asset" src="${A}back-ready.png" alt="뒤로가기"></button>`:''}
    <img class="alarm-title-asset" src="${A}title-alarm.png" alt="알람">
    ${label!=='알람'?`<span class="alarm-editor-title">${label}</span>`:''}
  </div></div>`;
}
function alarmCard(a){
  const tags=[
    `<span class="alarm-tag accent">${methodText(a)}</span>`,
    a.shakeEnabled?`<span class="alarm-tag">흔들기 ${a.shakeCount}회 · ${a.shakeStrength}</span>`:'',
    `<span class="alarm-tag">스누즈 ${a.snoozeMin}분</span>`,
    a.skipNext?`<span class="alarm-tag skip">다음 1회 건너뜀</span>`:''
  ].join('');
  return `<div class="card alarm-card-v2" data-alarm="${a.id}">
    <div class="alarm-card-top">
      <div class="alarm-card-time">${a.time}</div>
      <div class="alarm-card-copy"><b>${a.label||'알람'}</b><small>${dayText(a.days)}</small></div>
      <button class="switch ${a.enabled?'on':''}" data-toggle="${a.id}" aria-label="알람 켜기/끄기"></button>
    </div>
    <div class="alarm-tags">${tags}</div>
    <div class="alarm-card-actions">
      <div class="alarm-next-mini"><img src="${A}nav-alarm.png"><span>${nextAlarmText(a)}</span></div>
      ${a.enabled&&a.days.length?`<button class="alarm-skip-btn ${a.skipNext?'active':''}" data-skip="${a.id}">${a.skipNext?'건너뛰기 취소':'다음 1회 건너뛰기'}</button>`:''}
    </div>
  </div>`;
}
function renderAlarm(){
  if(alarmView==='edit'){renderAlarmEditor();return}
  if(alarmView==='ring'){renderAlarmRinging();return}
  setFocusMode(false);
  const next=activeAlarmForNext();
  screen.innerHTML=`
    <div class="alarm-page-head">
      <div class="alarm-page-title"><img class="alarm-title-asset" src="${A}title-alarm.png" alt="알람"></div>
      <button id="addAlarm" class="alarm-add-btn" aria-label="알람 추가">＋</button>
    </div>
    ${next?`<div class="card alarm-next-card">
      <div class="alarm-next-label"><img src="${A}nav-alarm.png">다음 알람</div>
      <div class="alarm-next-time">${nextAlarmText(next)}</div>
      <div class="alarm-next-sub">${next.label} · ${methodText(next)}${next.shakeEnabled?' · 흔들어서 끄기':''}</div>
    </div>`:''}
    <div class="alarm-list-v2">${alarms.map(alarmCard).join('')}</div>
    <button id="alarmDemo" class="alarm-test-link">알람 울림 화면 테스트</button>`;
  document.getElementById('addAlarm').onclick=()=>openAlarmEditor();
  document.getElementById('alarmDemo').onclick=()=>openRingingAlarm(activeAlarmForNext()?.id||alarms[0]?.id);
  document.querySelectorAll('[data-toggle]').forEach(btn=>btn.onclick=e=>{
    e.stopPropagation();const a=alarms.find(x=>x.id===+btn.dataset.toggle);a.enabled=!a.enabled;renderAlarm();
  });
  document.querySelectorAll('[data-skip]').forEach(btn=>btn.onclick=e=>{
    e.stopPropagation();const a=alarms.find(x=>x.id===+btn.dataset.skip);a.skipNext=!a.skipNext;renderAlarm();
  });
  document.querySelectorAll('[data-alarm]').forEach(row=>row.onclick=()=>openAlarmEditor(+row.dataset.alarm));
}
function defaultAlarmDraft(){
  return {
    id:null,time:'07:00',label:'',days:['월','화','수','목','금'],enabled:true,
    method:'sound',sound:'Morning Bell',ringtoneId:'basic',ttsText:'알람 시간입니다.',
    gradual:true,vibration:true,snoozeMin:10,snoozeCount:3,
    shakeEnabled:false,shakeCount:3,shakeStrength:'약하게',skipNext:false
  };
}
function cloneAlarm(a){return JSON.parse(JSON.stringify(a))}
function openAlarmEditor(id=null){
  editingAlarmId=id;
  alarmDraft=id?cloneAlarm(alarms.find(x=>x.id===id)):defaultAlarmDraft();
  ringtonePickerOpen=false;
  alarmView='edit';
  renderAlarm();
}
function closeAlarmEditor(){
  ringtonePickerOpen=false;alarmView='list';editingAlarmId=null;alarmDraft=null;renderAlarm();
}
function renderAlarmEditor(){
  setFocusMode(true);
  const a=alarmDraft||defaultAlarmDraft();
  screen.innerHTML=`
    <div class="alarm-editor">
      ${alarmHeader(editingAlarmId?'알람 수정':'새 알람',true)}

      <div class="alarm-section-label">시간</div>
      <div class="card wheel-time-card">
        <div class="wheel-time-caption">위아래로 밀어서 시간을 선택하세요</div>
        <div class="wheel-period-row">
          <button class="wheel-period-btn ${alarmPeriodFrom24(a.time)==='AM'?'active':''}" data-period="AM">오전</button>
          <button class="wheel-period-btn ${alarmPeriodFrom24(a.time)==='PM'?'active':''}" data-period="PM">오후</button>
        </div>
        <div class="wheel-wrap">
          <div class="wheel-highlight"></div><div class="wheel-fade-top"></div><div class="wheel-fade-bottom"></div>
          <div class="wheel-column" id="alarmHourWheel">
            <div class="wheel-spacer"></div>
            ${Array.from({length:12},(_,i)=>`<div class="wheel-item" data-value="${String(i+1).padStart(2,'0')}">${String(i+1).padStart(2,'0')}</div>`).join('')}
            <div class="wheel-spacer"></div>
          </div>
          <div class="wheel-colon">:</div>
          <div class="wheel-column" id="alarmMinuteWheel">
            <div class="wheel-spacer"></div>
            ${Array.from({length:60},(_,i)=>`<div class="wheel-item" data-value="${String(i).padStart(2,'0')}">${String(i).padStart(2,'0')}</div>`).join('')}
            <div class="wheel-spacer"></div>
          </div>
        </div>
      </div>

      <div class="alarm-section-label">반복</div>
      <div class="card alarm-section-card">
        <div class="alarm-preset-row">
          ${['한 번','매일','평일','주말'].map(p=>`<button class="alarm-preset ${alarmPresetActive(p,a.days)?'active':''}" data-preset="${p}">${p}</button>`).join('')}
        </div>
        <div class="alarm-days">
          ${['월','화','수','목','금','토','일'].map(d=>`<button class="alarm-chip ${a.days.includes(d)?'active':''}" data-day="${d}">${d}</button>`).join('')}
        </div>
      </div>

      <div class="alarm-section-label">알람 이름</div>
      <input id="alarmLabelV2" class="alarm-input" value="${escapeAlarmText(a.label)}" placeholder="예: 기상">

      <div class="alarm-section-label">울림 방식 · 하나만 선택</div>
      <div class="alarm-methods">
        <button class="alarm-method ${a.method==='sound'?'active':''}" data-method="sound">
          <img src="${A}settings-alarm.png"><b>알람 소리</b><small>선택한 알람음을 재생합니다.</small>
        </button>
        <button class="alarm-method ${a.method==='tts'?'active':''}" data-method="tts">
          <img src="${A}settings-sleep.png"><b>텍스트 읽기</b><small>입력한 문구를 음성으로 읽습니다.</small>
        </button>
      </div>

      ${a.method==='sound'?`
        <div class="alarm-section-label">알람 소리</div>
        <div class="card alarm-section-card">
          ${ringtonePickerMarkup(a)}
          <div class="alarm-field-row" style="margin-top:10px">
            <div class="alarm-field-copy"><b>점점 크게</b><small>작은 음량에서 설정 음량까지 서서히 증가</small></div>
            <button id="gradualToggle" class="switch ${a.gradual?'on':''}"></button>
          </div>
        </div>`:`
        <div class="alarm-section-label">읽을 문구</div>
        <div class="card alarm-section-card">
          <textarea id="alarmTtsText" class="alarm-textarea" maxlength="120" placeholder="예: 7시입니다. 일어날 시간이에요.">${escapeAlarmText(a.ttsText)}</textarea>
          <div style="display:flex;justify-content:flex-end;margin-top:8px"><button id="ttsPreview" class="alarm-preview-btn">텍스트 미리듣기</button></div>
        </div>`}

      <div class="alarm-section-label">진동</div>
      <div class="card alarm-section-card">
        <div class="alarm-field-row">
          <div class="alarm-field-copy"><b>진동 사용</b><small>소리 또는 텍스트 읽기와 함께 진동합니다.</small></div>
          <button id="vibrationToggle" class="switch ${a.vibration?'on':''}"></button>
        </div>
      </div>

      <div class="alarm-section-label">흔들어서 끄기</div>
      <div class="card alarm-section-card">
        <div class="alarm-field-row">
          <div class="alarm-field-copy"><b>흔들기 사용</b><small>알람 소리/텍스트 읽기와 동시에 사용할 수 있습니다.</small></div>
          <button id="shakeToggle" class="switch ${a.shakeEnabled?'on':''}"></button>
        </div>
        ${a.shakeEnabled?`
          <div class="alarm-field-row">
            <div class="alarm-field-copy"><b>필요 횟수</b><small>3회부터 선택</small></div>
            <div class="alarm-option-grid">${[3,5,7,10].map(n=>`<button class="alarm-option ${a.shakeCount===n?'active':''}" data-shake-count="${n}">${n}회</button>`).join('')}</div>
          </div>
          <div class="alarm-field-row">
            <div class="alarm-field-copy"><b>흔들기 세기</b><small>1회로 인정할 움직임의 강도</small></div>
            <div class="alarm-option-grid">${['약하게','강하게'].map(v=>`<button class="alarm-option ${a.shakeStrength===v?'active':''}" data-shake-strength="${v}">${v}</button>`).join('')}</div>
          </div>`:''}
      </div>

      <div class="alarm-section-label">스누즈</div>
      <div class="card alarm-section-card">
        <div class="alarm-field-row">
          <div class="alarm-field-copy"><b>다시 울리기</b><small>알람을 미룰 시간</small></div>
          <div class="alarm-option-grid">${[5,10,15].map(n=>`<button class="alarm-option ${a.snoozeMin===n?'active':''}" data-snooze-min="${n}">${n}분</button>`).join('')}</div>
        </div>
        <div class="alarm-field-row">
          <div class="alarm-field-copy"><b>최대 횟수</b><small>스누즈 허용 횟수</small></div>
          <div class="alarm-option-grid">${[1,3,5,99].map(n=>`<button class="alarm-option ${a.snoozeCount===n?'active':''}" data-snooze-count="${n}">${n===99?'무제한':n+'회'}</button>`).join('')}</div>
        </div>
      </div>

      <div class="alarm-section-label">알람 상태</div>
      <div class="card alarm-section-card">
        <div class="alarm-field-row">
          <div class="alarm-field-copy"><b>알람 사용</b><small>저장 후 지정된 시간에 동작합니다.</small></div>
          <button id="alarmEnabledV2" class="switch ${a.enabled?'on':''}"></button>
        </div>
      </div>

      <button id="alarmRingPreview" class="alarm-ring-test">이 설정으로 알람 울림 화면 테스트</button>

      <div class="alarm-editor-actions">
        <button id="alarmDeleteV2" class="alarm-delete-v2" style="${editingAlarmId?'':'visibility:hidden'}">삭제</button>
        <button id="alarmSaveV2" class="alarm-save-v2">저장</button>
      </div>
    </div>`;
  bindAlarmEditor();
}
function alarmPresetActive(p,days){
  if(p==='한 번')return days.length===0;
  if(p==='매일')return days.length===7;
  if(p==='평일')return days.join(',')==='월,화,수,목,금';
  if(p==='주말')return days.join(',')==='토,일';
  return false;
}
function escapeAlarmText(v=''){return String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')}

function ringtonePickerMarkup(a){
  const current=ringtoneById(a.ringtoneId||'basic');
  return `
    <button id="ringtoneOpen" class="ringtone-current">
      <img src="${A}settings-alarm.png" alt="">
      <div class="ringtone-current-copy">
        <b>${current.category} · ${current.name}</b>
        <small>${current.desc}</small>
      </div>
    </button>
    ${ringtonePickerOpen?`
      <div class="ringtone-picker">
        ${alarmRingtones.map(r=>`
          <div class="ringtone-option ${current.id===r.id?'active':''}" data-ringtone="${r.id}">
            <div class="ringtone-option-icon">${r.icon}</div>
            <div class="ringtone-option-copy">
              <b>${r.category} · ${r.name}</b>
              <small>${r.desc}</small>
            </div>
            <button class="ringtone-preview-mini" data-ringtone-preview="${r.id}">미리듣기</button>
          </div>`).join('')}
      </div>
      <div class="ringtone-coming">현재는 선택/미리듣기 구조를 먼저 적용한 목업입니다. 실제 야모네 전용 알람음 5종은 이후 직접 제작해 이 자리에 연결할 예정입니다.</div>`:''}
  `;
}


function alarmPeriodFrom24(time){
  const h=+String(time).split(':')[0];
  return h>=12?'PM':'AM';
}
function alarmHour12From24(time){
  let h=+String(time).split(':')[0];
  h=h%12;
  if(h===0)h=12;
  return String(h).padStart(2,'0');
}
function alarmTo24(period,h12,minute){
  let h=+h12;
  if(period==='AM'){
    if(h===12)h=0;
  }else{
    if(h!==12)h+=12;
  }
  return `${String(h).padStart(2,'0')}:${minute}`;
}

function bindAlarmEditor(){
  document.getElementById('alarmBack').onclick=closeAlarmEditor;
  let alarmPeriod=alarmPeriodFrom24(alarmDraft.time);
  let alarmHour12=alarmHour12From24(alarmDraft.time);
  let alarmMinute=alarmDraft.time.split(':')[1];

  setupAlarmWheel('alarmHourWheel',alarmHour12,v=>{
    alarmHour12=v;
    alarmDraft.time=alarmTo24(alarmPeriod,alarmHour12,alarmMinute);
  });
  setupAlarmWheel('alarmMinuteWheel',alarmMinute,v=>{
    alarmMinute=v;
    alarmDraft.time=alarmTo24(alarmPeriod,alarmHour12,alarmMinute);
  });

  document.querySelectorAll('[data-period]').forEach(btn=>btn.onclick=()=>{
    alarmPeriod=btn.dataset.period;
    alarmDraft.time=alarmTo24(alarmPeriod,alarmHour12,alarmMinute);
    renderAlarmEditor();
  });

  document.querySelectorAll('[data-preset]').forEach(b=>b.onclick=()=>{
    const p=b.dataset.preset;
    alarmDraft.days=p==='한 번'?[]:p==='매일'?['월','화','수','목','금','토','일']:p==='평일'?['월','화','수','목','금']:['토','일'];
    renderAlarmEditor();
  });
  document.querySelectorAll('[data-day]').forEach(b=>b.onclick=()=>{
    const d=b.dataset.day;
    alarmDraft.days=alarmDraft.days.includes(d)?alarmDraft.days.filter(x=>x!==d):[...alarmDraft.days,d];
    const order=['월','화','수','목','금','토','일'];
    alarmDraft.days.sort((x,y)=>order.indexOf(x)-order.indexOf(y));
    renderAlarmEditor();
  });

  document.getElementById('alarmLabelV2').oninput=e=>alarmDraft.label=e.target.value;
  document.querySelectorAll('[data-method]').forEach(b=>b.onclick=()=>{alarmDraft.method=b.dataset.method;renderAlarmEditor()});

  const grad=document.getElementById('gradualToggle');
  if(grad)grad.onclick=()=>{alarmDraft.gradual=!alarmDraft.gradual;renderAlarmEditor()};
  const ringtoneOpen=document.getElementById('ringtoneOpen');
  if(ringtoneOpen)ringtoneOpen.onclick=()=>{ringtonePickerOpen=!ringtonePickerOpen;renderAlarmEditor()};
  document.querySelectorAll('[data-ringtone]').forEach(row=>row.onclick=e=>{
    if(e.target.closest('[data-ringtone-preview]'))return;
    alarmDraft.ringtoneId=row.dataset.ringtone;
    const r=ringtoneById(alarmDraft.ringtoneId);
    alarmDraft.sound=r.name;
    ringtonePickerOpen=false;
    renderAlarmEditor();
  });
  document.querySelectorAll('[data-ringtone-preview]').forEach(btn=>btn.onclick=e=>{
    e.stopPropagation();
    const r=ringtoneById(btn.dataset.ringtonePreview);
    say(`${r.category} · ${r.name} 미리듣기 목업`);
  });
  const tts=document.getElementById('alarmTtsText');
  if(tts)tts.oninput=e=>alarmDraft.ttsText=e.target.value;
  const ttsPreview=document.getElementById('ttsPreview');
  if(ttsPreview)ttsPreview.onclick=()=>say((alarmDraft.ttsText||'알람 시간입니다.').slice(0,22)+' · 읽기 미리듣기');

  document.getElementById('vibrationToggle').onclick=()=>{alarmDraft.vibration=!alarmDraft.vibration;renderAlarmEditor()};
  document.getElementById('shakeToggle').onclick=()=>{alarmDraft.shakeEnabled=!alarmDraft.shakeEnabled;renderAlarmEditor()};
  document.querySelectorAll('[data-shake-count]').forEach(b=>b.onclick=()=>{alarmDraft.shakeCount=+b.dataset.shakeCount;renderAlarmEditor()});
  document.querySelectorAll('[data-shake-strength]').forEach(b=>b.onclick=()=>{alarmDraft.shakeStrength=b.dataset.shakeStrength;renderAlarmEditor()});
  document.querySelectorAll('[data-snooze-min]').forEach(b=>b.onclick=()=>{alarmDraft.snoozeMin=+b.dataset.snoozeMin;renderAlarmEditor()});
  document.querySelectorAll('[data-snooze-count]').forEach(b=>b.onclick=()=>{alarmDraft.snoozeCount=+b.dataset.snoozeCount;renderAlarmEditor()});
  document.getElementById('alarmEnabledV2').onclick=()=>{alarmDraft.enabled=!alarmDraft.enabled;renderAlarmEditor()};

  document.getElementById('alarmRingPreview').onclick=()=>{
    alarmDraft.label=document.getElementById('alarmLabelV2').value.trim()||'알람';
    const t=document.getElementById('alarmTtsText'); if(t)alarmDraft.ttsText=t.value;
    openRingingAlarm(null,true);
  };
  document.getElementById('alarmSaveV2').onclick=saveAlarmV2;
  const del=document.getElementById('alarmDeleteV2');
  if(del)del.onclick=deleteAlarmV2;
}
function setupAlarmWheel(id,value,onChange){
  const el=document.getElementById(id); if(!el)return;
  const items=[...el.querySelectorAll('.wheel-item')];
  const idx=items.findIndex(x=>x.dataset.value===value);
  requestAnimationFrame(()=>{
    el.scrollTop=Math.max(0,idx*44);
    updateWheelSelected(el,onChange,false);
  });
  let t=null;
  el.addEventListener('scroll',()=>{
    clearTimeout(t);
    t=setTimeout(()=>updateWheelSelected(el,onChange,true),60);
  },{passive:true});
  items.forEach(item=>item.onclick=()=>{
    el.scrollTo({top:items.indexOf(item)*44,behavior:'smooth'});
  });
}
function updateWheelSelected(el,onChange,commit=true){
  const items=[...el.querySelectorAll('.wheel-item')];
  let idx=Math.round(el.scrollTop/44);
  idx=Math.max(0,Math.min(items.length-1,idx));
  items.forEach((x,i)=>x.classList.toggle('selected',i===idx));
  if(commit)onChange(items[idx].dataset.value);
}
function saveAlarmV2(){
  alarmDraft.label=document.getElementById('alarmLabelV2').value.trim()||'알람';
  const t=document.getElementById('alarmTtsText'); if(t)alarmDraft.ttsText=t.value.trim()||'알람 시간입니다.';
  if(editingAlarmId){
    const idx=alarms.findIndex(x=>x.id===editingAlarmId);
    alarms[idx]={...alarmDraft,id:editingAlarmId};
  }else{
    alarms.push({...alarmDraft,id:alarmSeq++});
  }
  alarmView='list';editingAlarmId=null;alarmDraft=null;setFocusMode(false);renderAlarm();say('알람이 저장되었습니다.');
}
function deleteAlarmV2(){
  if(!editingAlarmId)return;
  alarms=alarms.filter(x=>x.id!==editingAlarmId);
  alarmView='list';editingAlarmId=null;alarmDraft=null;setFocusMode(false);renderAlarm();say('알람이 삭제되었습니다.');
}
function openRingingAlarm(id=null,useDraft=false){
  ringingAlarmId=id;
  shakeProgress=0;
  if(useDraft){
    window.__alarmPreview=cloneAlarm(alarmDraft);
  }else{
    window.__alarmPreview=null;
  }
  alarmView='ring';
  renderAlarm();
}
function currentRingingAlarm(){
  return window.__alarmPreview || alarms.find(x=>x.id===ringingAlarmId) || defaultAlarmDraft();
}
function renderAlarmRinging(){
  setFocusMode(true);
  const a=currentRingingAlarm();
  const ring=ringtoneById(a.ringtoneId||'basic');
  const method=a.method==='tts'?(a.ttsText||'알람 시간입니다.'):`${ring.category} · ${ring.name}${a.gradual?' · 점점 크게':''}`;
  screen.innerHTML=`
    <div class="alarm-ringing">
      <div class="alarm-ring-hero">
        <img class="alarm-ring-icon" src="${A}settings-alarm.png" alt="">
        <div class="alarm-ring-now">${a.time}</div>
        <div class="alarm-ring-label">${escapeAlarmText(a.label||'알람')}</div>
        <div class="alarm-ring-method">${a.method==='tts'?'텍스트 읽기':'알람 소리'} · ${escapeAlarmText(method)}</div>
      </div>

      ${a.shakeEnabled?`
        <div class="card alarm-shake-card">
          <img src="${A}activity-move.png" alt="">
          <h3>흔들어서 끄기</h3>
          <p>${a.shakeStrength} · ${a.shakeCount}회 필요</p>
          <div class="alarm-shake-progress">${Array.from({length:a.shakeCount},(_,i)=>`<i class="alarm-shake-dot ${i<shakeProgress?'done':''}"></i>`).join('')}</div>
          <button id="shakeSim" class="alarm-shake-sim">흔들기 테스트 · ${shakeProgress}/${a.shakeCount}</button>
        </div>`:''}

      <div class="alarm-ring-actions">
        <button id="ringSnooze" class="alarm-snooze-btn">다시 알림<br>${a.snoozeMin}분</button>
        <button id="ringDismiss" class="alarm-dismiss-btn">알람 종료</button>
      </div>
      <div class="alarm-ring-note">${a.shakeEnabled?'설정한 횟수만큼 흔들면 자동으로 종료됩니다.':''}${a.vibration?' · 진동 사용':''}</div>
    </div>`;
  const sim=document.getElementById('shakeSim');
  if(sim)sim.onclick=()=>{
    shakeProgress=Math.min(a.shakeCount,shakeProgress+1);
    if(shakeProgress>=a.shakeCount){say('흔들기 완료 · 알람 종료');setTimeout(closeRingingAlarm,500)}else renderAlarmRinging();
  };
  document.getElementById('ringSnooze').onclick=()=>{say(`${a.snoozeMin}분 뒤 다시 울립니다.`);closeRingingAlarm()};
  document.getElementById('ringDismiss').onclick=()=>{say('알람을 종료했습니다.');closeRingingAlarm()};
}
function closeRingingAlarm(){
  window.__alarmPreview=null;ringingAlarmId=null;shakeProgress=0;alarmView='list';setFocusMode(false);renderAlarm();
}

function sr(icon,title,sub){return `<div class="card setting" data-setting="${title}"><img src="${A}${icon}.png"><div class="setting-copy"><b>${title}</b><small>${sub}</small></div><span class="arrow">›</span></div>`}
function renderSettings(){
  let theme=document.body.dataset.theme;
  screen.innerHTML=`
    <h1 class="title">설정</h1>
    <div class="section">테마</div>
    <div class="theme-grid">
      <button class="theme-card ${theme==='mint'?'selected':''}" data-theme-choice="mint"><img src="${A}theme-mint.png"><b>민트</b></button>
      <button class="theme-card ${theme==='pink'?'selected':''}" data-theme-choice="pink"><img src="${A}theme-pink.png"><b>핑크</b></button>
    </div>
    <div class="section">설정 메뉴</div>
    <div class="setting-list">
      ${sr('settings-auto-detect','자동감지','걷기 · 달리기 · 자전거')}
      ${sr('settings-snow','Snow','자동감지 · 오프라인 지도')}
      ${sr('settings-sleep','수면','코골이 감지')}
      ${sr('settings-alarm','알람','스누즈 · 진동')}
      ${sr('settings-permission','권한','권한 상태 확인')}
      ${sr('settings-data-storage','데이터 / 저장','기록 삭제 · 저장공간')}
      ${sr('settings-app-info','앱 정보','Version 0.00.23')}
    </div>`;
  document.querySelectorAll('[data-theme-choice]').forEach(x=>x.onclick=(e)=>{
    e.stopPropagation();
    document.body.dataset.theme=x.dataset.themeChoice;
    renderSettings();
  });
  document.querySelectorAll('[data-setting]').forEach(x=>x.onclick=()=>{
    settingPage=x.dataset.setting;
    view='setting';
    render();
  });
}

function setFocusMode(on){phone.classList.toggle('focus-mode',on)}

function moveTop(title,sub){
  let backFile='back-ready.png';
  let headerInner='';
  if(title==='걷기 · 달리기 · 자전거'){
    backFile='back-ready.png';
    headerInner=`<img class="move-title-asset move-title-prep" src="${A}title-move-prep.png" alt="걷기 달리기 자전거">`;
  }else if(title==='이동 활동 기록'){
    backFile='back-recording.png';
    headerInner=`<img class="move-title-asset move-title-live" src="${A}title-move-live.png" alt="이동 활동 기록">`;
  }else{
    backFile='back-recording.png';
    headerInner=`<h1 class="move-plain-title">${title}</h1>`;
  }
  return `<div class="move-sticky"><div class="move-header-row"><button id="moveBack" class="move-back-asset-btn"><img class="move-back-asset" src="${A}${backFile}" alt="뒤로가기"></button>${headerInner}</div></div>`;
}
function moveReady(){
  setFocusMode(true);
  screen.innerHTML=`
    ${moveTop('걷기 · 달리기 · 자전거','활동 시작 준비')}
    <section class="card move-hero">
      <img class="move-hero-icon" src="${A}move-main.png" alt="">
      <div class="move-hero-copy">
        <h2>이동 활동 시작</h2>
        <div class="move-badges">
          <span class="move-badge"><img src="${A}gps.png">GPS 양호</span>
          <span class="move-badge"><img src="${A}auto-switch.png">자동 구분 가능</span>
        </div>
      </div>
    </section>
    <div class="move-section">시작 방식</div>
    <div class="move-mode-grid">
      ${moveModeButton('auto','auto-switch.png','자동 전환','자동 구분')}
      ${moveModeButton('walk','walk.png','걷기','페이스')}
      ${moveModeButton('run','run.png','달리기','페이스')}
      ${moveModeButton('bike','bike.png','자전거','속도')}
    </div>
    <div class="move-section">기록 상태</div>
    <div class="move-status-grid">
      <div class="card move-status"><img src="${A}gps.png"><div><b>GPS 신호</b><small>실외 기록에 적합한 상태입니다.</small></div></div>
      <div class="card move-status"><img src="${A}route.png"><div><b>운동 경로</b><small>기록 중 작은 지도 카드가 표시됩니다.</small></div></div>
    </div>
    <div class="move-section">안내</div>
    <div class="move-note">자동 전환은 이동 속도와 움직임을 바탕으로 걷기·달리기·자전거 구간을 하나의 기록 안에서 이어서 저장합니다.</div>
    <button id="moveStart" class="move-start">활동 시작</button>`;
  bindMoveBack();
  document.querySelectorAll('[data-move-mode]').forEach(b=>b.onclick=()=>{moveMode=b.dataset.moveMode;if(moveMode!=='auto')moveSubtype=moveMode;moveReady()});
  document.getElementById('moveStart').onclick=()=>{if(moveMode==='auto')moveSubtype='run';moveState='recording';render()};
}
function moveModeButton(key,icon,label,sub){return `<button class="move-mode ${moveMode===key?'active':''}" data-move-mode="${key}"><img src="${A}${icon}"><b>${label}</b><small>${sub}</small></button>`}

function movePrimary(){
  const t=moveMode==='auto'?moveSubtype:moveMode;
  if(t==='bike')return `<div class="move-primary"><div class="move-primary-head"><img src="${A}speed.png"><b>현재 속도</b></div><div class="move-primary-value">21.8 km/h</div><div class="move-primary-sub">평균 속도 18.6 km/h · 자전거 감지 중</div></div>`;
  return `<div class="move-primary"><div class="move-primary-head"><img src="${A}pace.png"><b>현재 페이스</b></div><div class="move-primary-value">${t==='walk'?"11'20″/km":"5'48″/km"}</div><div class="move-primary-sub">평균 페이스 ${t==='walk'?"10'52″/km":"5'56″/km"} · ${t==='walk'?'걷기':'달리기'} 감지 중</div></div>`;
}
function moveLive(paused){
  setFocusMode(true);
  const t=moveMode==='auto'?moveSubtype:moveMode;
  const label=t==='walk'?'걷기':t==='run'?'달리기':'자전거';
  screen.innerHTML=`
    ${moveTop('이동 활동 기록',paused?'일시정지':'기록 중')}
    <section class="card move-live-card">
      <div class="move-live-head">
        <div class="move-live-left"><img src="${A}${t}.png"><div><h2>${label} ${paused?'일시정지':'기록 중'}</h2></div></div>
        <span class="move-auto-pill">${moveMode==='auto'?'자동 전환':'수동 시작'}</span>
      </div>
      ${movePrimary()}
      <div class="move-metrics">
        <div class="card move-metric"><img src="${A}time.png"><span>시간</span><strong>00:38:14</strong></div>
        <div class="card move-metric"><img src="${A}distance.png"><span>거리</span><strong>${t==='bike'?'12.4 km':'5.2 km'}</strong></div>
        <div class="card move-metric"><img src="${A}calorie.png"><span>칼로리</span><strong>${t==='bike'?'284':'418'} kcal</strong></div>
      </div>
      <div class="card move-map"><img src="${A}route.png"><div><b>운동 경로</b><p>실제 앱에서는 현재 위치와 이동 경로가 표시됩니다.</p></div></div>
      <div class="card move-segments">
        <h3>자동 구간 구분</h3>
        <div class="move-segment"><img src="${A}walk.png"><div><b>걷기</b><small>00:00 ~ 00:07</small></div><strong>0.52 km</strong></div>
        <div class="move-segment"><img src="${A}run.png"><div><b>달리기</b><small>00:08 ~ 00:27</small></div><strong>3.10 km</strong></div>
        <div class="move-segment"><img src="${A}bike.png"><div><b>자전거</b><small>00:28 ~ 현재</small></div><strong>1.58 km</strong></div>
      </div>
      <div class="move-controls">
        ${paused
          ? `<button id="moveResume" class="move-control resume"><img src="${A}resume.png"><b>다시 시작</b><small>기록 재개</small></button>`
          : `<button id="movePause" class="move-control pause"><img src="${A}pause.png"><b>일시정지</b><small>잠시 멈춤</small></button>`}
        <button id="moveStop" class="move-control stop"><img src="${A}stop.png"><b>운동 종료</b><small>요약 후 저장</small></button>
        <button class="move-control"><img src="${A}gps.png"><b>GPS 상태</b><small>양호</small></button>
      </div>
    </section>`;
  bindMoveBack();
  const p=document.getElementById('movePause'),r=document.getElementById('moveResume'),s=document.getElementById('moveStop');
  if(p)p.onclick=()=>{moveState='paused';render()};
  if(r)r.onclick=()=>{moveState='recording';render()};
  s.onclick=openMoveStop;
}
function moveSummary(){
  setFocusMode(true);
  const t=moveMode==='auto'?moveSubtype:moveMode;
  const label=t==='walk'?'걷기':t==='run'?'달리기':'자전거';
  screen.innerHTML=`
    ${moveTop('운동 요약','종료 후 저장 전')}
    <section class="card move-summary-top"><img src="${A}complete.png"><h2>이동 활동이 완료되었어요</h2></section>
    <div class="move-summary-grid">
      <div class="card move-summary-item"><img src="${A}time.png"><div><b>총 시간</b><strong>00:38:14</strong></div></div>
      <div class="card move-summary-item"><img src="${A}distance.png"><div><b>총 거리</b><strong>${t==='bike'?'12.4 km':'5.2 km'}</strong></div></div>
      <div class="card move-summary-item"><img src="${A}calorie.png"><div><b>칼로리</b><strong>${t==='bike'?'284':'418'} kcal</strong></div></div>
      <div class="card move-summary-item"><img src="${A}${t}.png"><div><b>마지막 활동</b><strong>${label}</strong></div></div>
    </div>
    <div class="move-section">구간 요약</div>
    <div class="card move-segments">
      <div class="move-segment"><img src="${A}walk.png"><div><b>걷기</b><small>시작 7분</small></div><strong>0.52 km</strong></div>
      <div class="move-segment"><img src="${A}run.png"><div><b>달리기</b><small>중간 20분</small></div><strong>3.10 km</strong></div>
      <div class="move-segment"><img src="${A}bike.png"><div><b>자전거</b><small>마지막 11분</small></div><strong>1.58 km</strong></div>
    </div>
    <button id="moveSave" class="move-save">확인하고 저장</button>`;
  bindMoveBack();
  document.getElementById('moveSave').onclick=()=>{say('기록에 저장된 것으로 처리한 목업입니다.');view='main';tab='records';setFocusMode(false);syncTabs();render()};
}
function bindMoveBack(){document.getElementById('moveBack').onclick=()=>{view='main';moveState='ready';setFocusMode(false);tab='activity';syncTabs();render()}}
function openMoveStop(){
  moveOverlay.classList.add('show');
  moveOverlay.innerHTML=`<div class="move-sheet"><div class="move-sheet-handle"></div><h3>운동을 종료할까요?</h3><p>종료하면 운동 요약 화면으로 이동합니다.</p><div class="move-sheet-actions"><button id="moveKeep" class="move-sheet-cancel">계속 기록</button><button id="moveConfirm" class="move-sheet-stop">종료</button></div></div>`;
  document.getElementById('moveKeep').onclick=closeMoveOverlay;
  document.getElementById('moveConfirm').onclick=()=>{closeMoveOverlay();moveState='summary';render()};
  moveOverlay.onclick=e=>{if(e.target===moveOverlay)closeMoveOverlay()};
}
function closeMoveOverlay(){moveOverlay.classList.remove('show');moveOverlay.innerHTML=''}

function snowTop(live=false){
  const title=live?'title-snow-live.png':'title-snow.png';
  const back=live?'back-recording.png':'back-ready.png';
  return `<div class="move-sticky"><div class="move-header-row"><button id="snowBack" class="move-back-asset-btn"><img class="move-back-asset" src="${A}${back}" alt="뒤로가기"></button><img class="${live?'snow-title-live':'snow-title-prep'}" src="${A}${title}" alt="${live?'Snow 기록':'Snow'}"></div></div>`;
}
function snowReady(){
  setFocusMode(true);
  screen.innerHTML=`
    ${snowTop(false)}
    <section class="card snow-hero">
      <img src="${A}activity-snow.png" alt="">
      <div class="snow-hero-copy"><h2>Snow 시작</h2></div>
    </section>

    <div class="move-section">현재 스키장</div>
    <div class="card snow-resort-card">
      <img src="${A}activity-snow.png" alt="">
      <div><b>스키장 감지</b><strong>경계 안 · 시작 가능</strong></div>
    </div>

    <div class="move-section">준비 상태</div>
    <div class="snow-status-grid">
      <div class="card snow-status"><img src="${A}gps.png"><div><b>GPS</b><strong>양호</strong></div></div>
      <div class="card snow-status"><img src="${A}route.png"><div><b>오프라인 지도</b><strong>준비됨</strong></div></div>
    </div>

    <div class="snow-note">같은 스키장·같은 날짜의 기록은 하루 기록 하나로 이어집니다.</div>
    <button id="snowStart" class="snow-start">Snow 시작</button>`;
  bindSnowBack();
  document.getElementById('snowStart').onclick=()=>{snowState='recording';snowMotion='downhill';render()};
}
function snowLive(paused=false){
  setFocusMode(true);
  const stateLabel=snowMotion==='downhill'?'활주 중':snowMotion==='lift'?'리프트 탑승':'정지';
  screen.innerHTML=`
    ${snowTop(true)}
    <section class="card snow-live-card">
      <div class="snow-live-head">
        <div class="snow-live-left"><img src="${A}activity-snow.png"><div><h2>${paused?'일시정지':stateLabel}</h2></div></div>
        <span class="snow-state-pill">${paused?'기록 정지':'Snow 기록 중'}</span>
      </div>

      <div class="snow-state-switch">
        <button class="snow-state-btn ${snowMotion==='downhill'?'active':''}" data-snow-motion="downhill">활주</button>
        <button class="snow-state-btn ${snowMotion==='lift'?'active':''}" data-snow-motion="lift">리프트</button>
        <button class="snow-state-btn ${snowMotion==='stationary'?'active':''}" data-snow-motion="stationary">정지</button>
      </div>

      <div class="snow-primary">
        <div class="snow-primary-head"><img src="${A}speed.png"><b>${snowMotion==='downhill'?'현재 속도':snowMotion==='lift'?'리프트 상태':'현재 상태'}</b></div>
        <div class="snow-primary-value">${snowMotion==='downhill'?'42.8 km/h':snowMotion==='lift'?'탑승 중':'정지'}</div>
        <div class="snow-primary-sub">${snowMotion==='downhill'?'최고 속도 61.4 km/h':snowMotion==='lift'?'이번 리프트 06:18':'03:42 동안 정지'}</div>
      </div>

      <div class="snow-metrics">
        <div class="card snow-metric"><img src="${A}time.png"><span>시간</span><strong>03:42:18</strong></div>
        <div class="card snow-metric"><img src="${A}distance.png"><span>활주 거리</span><strong>28.7 km</strong></div>
        <div class="card snow-metric"><img src="${A}activity-snow.png"><span>활주</span><strong>14회</strong></div>
      </div>

      <div class="card snow-map">
        <img src="${A}route.png"><div><b>스키장 지도</b><small>활주 경로 · 리프트 · 슬로프 구간 표시</small></div>
      </div>

      <div class="card snow-run-card">
        <h3>오늘 기록</h3>
        <div class="snow-run-row"><div><b>활주</b><small>다운힐 누적</small></div><strong>14회 · 28.7 km</strong></div>
        <div class="snow-run-row"><div><b>리프트</b><small>탑승 누적</small></div><strong>11회 · 01:18:22</strong></div>
        <div class="snow-run-row"><div><b>고도차</b><small>누적 수직 이동</small></div><strong>4,280 m</strong></div>
      </div>

      <div class="snow-controls">
        ${paused
          ? `<button id="snowResume" class="snow-control resume"><img src="${A}resume.png"><b>다시 시작</b><small>기록 재개</small></button>`
          : `<button id="snowPause" class="snow-control pause"><img src="${A}pause.png"><b>일시정지</b><small>잠시 멈춤</small></button>`}
        <button id="snowStop" class="snow-control stop"><img src="${A}stop.png"><b>Snow 종료</b><small>요약 후 저장</small></button>
        <button class="snow-control"><img src="${A}gps.png"><b>GPS</b><small>양호</small></button>
      </div>
    </section>`;
  bindSnowBack();
  document.querySelectorAll('[data-snow-motion]').forEach(b=>b.onclick=()=>{snowMotion=b.dataset.snowMotion;render()});
  const p=document.getElementById('snowPause'),r=document.getElementById('snowResume'),s=document.getElementById('snowStop');
  if(p)p.onclick=()=>{snowState='paused';render()};
  if(r)r.onclick=()=>{snowState='recording';render()};
  s.onclick=openSnowStop;
}
function snowSummary(){
  setFocusMode(true);
  screen.innerHTML=`
    ${snowTop(true)}
    <section class="card snow-summary-top">
      <img src="${A}activity-snow.png">
      <h2>오늘 Snow 기록 완료</h2>
    </section>

    <div class="snow-summary-grid">
      <div class="card snow-summary-item"><img src="${A}time.png"><div><b>총 시간</b><strong>06:12:44</strong></div></div>
      <div class="card snow-summary-item"><img src="${A}distance.png"><div><b>활주 거리</b><strong>38.6 km</strong></div></div>
      <div class="card snow-summary-item"><img src="${A}speed.png"><div><b>최고 속도</b><strong>64.2 km/h</strong></div></div>
      <div class="card snow-summary-item"><img src="${A}activity-snow.png"><div><b>활주 횟수</b><strong>19회</strong></div></div>
      <div class="card snow-summary-item"><img src="${A}activity-snow.png"><div><b>리프트</b><strong>15회</strong></div></div>
      <div class="card snow-summary-item"><img src="${A}route.png"><div><b>누적 고도차</b><strong>5,840 m</strong></div></div>
    </div>

    <div class="snow-note">오늘 같은 스키장에 다시 들어오면 이 기록에 이어서 저장되는 구조입니다.</div>
    <button id="snowSave" class="snow-save">확인하고 저장</button>`;
  bindSnowBack();
  document.getElementById('snowSave').onclick=()=>{say('Snow 기록에 저장된 것으로 처리한 목업입니다.');view='main';snowState='ready';tab='records';setFocusMode(false);syncTabs();render()};
}
function bindSnowBack(){
  document.getElementById('snowBack').onclick=()=>{view='main';snowState='ready';setFocusMode(false);tab='activity';syncTabs();render()}
}
function openSnowStop(){
  moveOverlay.classList.add('show');
  moveOverlay.innerHTML=`<div class="move-sheet"><div class="move-sheet-handle"></div><h3>Snow 기록을 종료할까요?</h3><p>종료하면 오늘 기록 요약 화면으로 이동합니다.</p><div class="move-sheet-actions"><button id="snowKeep" class="move-sheet-cancel">계속 기록</button><button id="snowConfirm" class="move-sheet-stop">종료</button></div></div>`;
  document.getElementById('snowKeep').onclick=closeMoveOverlay;
  document.getElementById('snowConfirm').onclick=()=>{closeMoveOverlay();snowState='summary';render()};
  moveOverlay.onclick=e=>{if(e.target===moveOverlay)closeMoveOverlay()};
}


const sleepBars=[18,22,16,28,24,19,30,35,26,23,18,20,25,31,42,55,36,29,24,21,18,16,22,34,47,62,71,53,38,29,25,21,18,20,27,33,41,65,78,72,49,35,28,22,18,17,25,39,58,81,76,54,39,31,26,20,18,23,37,49,68,57,43,30,24,20,18,16,22,30,44,61,50,36,27,23,19,17,16,18];
const sleepEvents=[18,19,37,38,39,48,49,60,61,62,71];

function sleepTop(live=false){
  const title=live?'title-sleep-live.png':'title-sleep.png';
  const back=live?'back-recording.png':'back-ready.png';
  return `<div class="move-sticky"><div class="move-header-row"><button id="sleepBack" class="move-back-asset-btn"><img class="move-back-asset" src="${A}${back}" alt="뒤로가기"></button><img class="${live?'sleep-title-live':'sleep-title-prep'}" src="${A}${title}" alt="${live?'수면 기록':'수면'}"></div></div>`;
}
function sleepChartMarkup(cursor=0,interactive=false){
  return `<div class="sleep-chart" id="${interactive?'sleepPlaybackChart':'sleepLiveChart'}">
    <div class="sleep-bars">${sleepBars.map((h,i)=>`<i class="sleep-bar" style="height:${h}%"></i>`).join('')}</div>
    ${sleepEvents.map(i=>`<i class="sleep-event" style="left:${(i/(sleepBars.length-1))*100}%;height:${Math.min(78,sleepBars[i]+16)}%"></i>`).join('')}
    ${interactive?`<i class="sleep-cursor" id="sleepCursor" style="left:${cursor}%"></i>`:''}
    <div class="sleep-axis"><span>23:30</span><span>01:30</span><span>03:30</span><span>05:30</span><span>07:10</span></div>
  </div>`;
}
function sleepReady(){
  setFocusMode(true);
  screen.innerHTML=`
    ${sleepTop(false)}
    <section class="card sleep-hero">
      <img src="${A}activity-sleep.png" alt="">
      <div class="sleep-hero-copy"><h2>수면 기록 시작</h2></div>
    </section>

    <div class="move-section">준비 상태</div>
    <div class="sleep-ready-grid">
      <div class="card sleep-ready-card"><img src="${A}settings-permission.png"><div><b>마이크</b><strong>사용 가능</strong></div></div>
      <div class="card sleep-ready-card"><img src="${A}settings-data-storage.png"><div><b>저장 공간</b><strong>준비됨</strong></div></div>
    </div>

    <div class="sleep-note">수면과 소리 분석 데이터는 기본적으로 기기에 저장되는 목업 흐름입니다.</div>
    <button id="sleepStart" class="sleep-start">수면 기록 시작</button>`;
  bindSleepBack();
  document.getElementById('sleepStart').onclick=()=>{sleepState='recording';render()};
}
function sleepLive(){
  setFocusMode(true);
  screen.innerHTML=`
    ${sleepTop(true)}
    <section class="card sleep-live-card">
      <div class="sleep-live-head">
        <div class="sleep-live-left"><img src="${A}activity-sleep.png"><div><h2>수면 기록 중</h2></div></div>
        <span class="sleep-live-pill">녹음 중</span>
      </div>

      <div class="sleep-current">
        <div class="sleep-current-top"><img src="${A}activity-sleep.png"><b>현재 소리 수준</b></div>
        <div class="sleep-current-value">34 dB</div>
        <div class="sleep-current-sub">조용한 구간 · 코골이 후보 없음</div>
      </div>

      <div class="sleep-metrics">
        <div class="card sleep-metric"><img src="${A}time.png"><span>기록 시간</span><strong>02:18:35</strong></div>
        <div class="card sleep-metric"><img src="${A}activity-sleep.png"><span>후보 구간</span><strong>7개</strong></div>
        <div class="card sleep-metric"><img src="${A}settings-data-storage.png"><span>저장</span><strong>로컬</strong></div>
      </div>

      <div class="card sleep-chart-card">
        <div class="sleep-chart-title"><b>소리 크기</b><span>최근 흐름</span></div>
        ${sleepChartMarkup(0,false)}
      </div>

      <div class="sleep-controls">
        <button id="sleepStop" class="sleep-control stop">수면 기록 종료</button>
        <button class="sleep-control" id="sleepCandidate">코골이 후보 보기</button>
      </div>
    </section>`;
  bindSleepBack();
  document.getElementById('sleepStop').onclick=openSleepStop;
  document.getElementById('sleepCandidate').onclick=()=>say('현재까지 코골이 후보 7개로 표시한 목업입니다.');
}
function sleepSummary(){
  setFocusMode(true);
  const pct=(sleepPosition/(7*60*60+40*60))*100;
  screen.innerHTML=`
    ${sleepTop(true)}
    <section class="card sleep-summary-top">
      <img src="${A}activity-sleep.png">
      <h2>수면 기록 완료</h2>
    </section>

    <div class="sleep-summary-grid">
      <div class="card sleep-summary-item"><img src="${A}time.png"><div><b>총 수면 기록</b><strong>7시간 40분</strong></div></div>
      <div class="card sleep-summary-item"><img src="${A}activity-sleep.png"><div><b>코골이 후보</b><strong>11개</strong></div></div>
      <div class="card sleep-summary-item"><img src="${A}settings-data-storage.png"><div><b>저장 위치</b><strong>기기 내부</strong></div></div>
      <div class="card sleep-summary-item"><img src="${A}settings-permission.png"><div><b>분석 상태</b><strong>완료</strong></div></div>
    </div>

    <div class="card sleep-playback">
      <div class="sleep-playback-top">
        <button id="sleepPlayBtn" class="sleep-play-btn"><img src="${A}${sleepPlaying?'pause.png':'resume.png'}"></button>
        <div class="sleep-playback-time" id="sleepPlaybackTime">${formatSleepTime(sleepPosition)} / 07:40:00</div>
      </div>
      ${sleepChartMarkup(pct,true)}
    </div>

    <div class="sleep-note">그래프의 원하는 지점을 누르면 해당 시점으로 재생 위치가 이동합니다. 분홍색 막대는 코골이 후보 구간입니다.</div>
    <button id="sleepSave" class="sleep-save">확인하고 저장</button>`;
  bindSleepBack();
  bindSleepPlayback();
  document.getElementById('sleepSave').onclick=()=>{stopSleepTimer();say('수면 기록에 저장된 것으로 처리한 목업입니다.');view='main';sleepState='ready';tab='records';setFocusMode(false);syncTabs();render()};
}
function bindSleepBack(){
  document.getElementById('sleepBack').onclick=()=>{stopSleepTimer();view='main';sleepState='ready';sleepPlaying=false;setFocusMode(false);tab='activity';syncTabs();render()}
}
function openSleepStop(){
  moveOverlay.classList.add('show');
  moveOverlay.innerHTML=`<div class="move-sheet"><div class="move-sheet-handle"></div><h3>수면 기록을 종료할까요?</h3><p>종료하면 소리 그래프와 코골이 후보를 확인할 수 있습니다.</p><div class="move-sheet-actions"><button id="sleepKeep" class="move-sheet-cancel">계속 기록</button><button id="sleepConfirm" class="move-sheet-stop">종료</button></div></div>`;
  document.getElementById('sleepKeep').onclick=closeMoveOverlay;
  document.getElementById('sleepConfirm').onclick=()=>{closeMoveOverlay();sleepState='summary';sleepPosition=2*60*60+18*60+35;render()};
  moveOverlay.onclick=e=>{if(e.target===moveOverlay)closeMoveOverlay()};
}
let sleepTimer=null;
function totalSleepSeconds(){return 7*60*60+40*60}
function formatSleepTime(sec){
  sec=Math.max(0,Math.min(totalSleepSeconds(),Math.floor(sec)));
  const h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),s=sec%60;
  return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
}
function bindSleepPlayback(){
  const chart=document.getElementById('sleepPlaybackChart');
  const btn=document.getElementById('sleepPlayBtn');
  chart.onclick=e=>{
    const r=chart.getBoundingClientRect();
    const ratio=Math.max(0,Math.min(1,(e.clientX-r.left)/r.width));
    sleepPosition=Math.floor(totalSleepSeconds()*ratio);
    updateSleepPlaybackUI();
  };
  btn.onclick=()=>{
    sleepPlaying=!sleepPlaying;
    if(sleepPlaying)startSleepTimer(); else stopSleepTimer();
    render();
  };
  if(sleepPlaying)startSleepTimer();
}
function updateSleepPlaybackUI(){
  const c=document.getElementById('sleepCursor');
  const t=document.getElementById('sleepPlaybackTime');
  if(c)c.style.left=`${(sleepPosition/totalSleepSeconds())*100}%`;
  if(t)t.textContent=`${formatSleepTime(sleepPosition)} / 07:40:00`;
}
function startSleepTimer(){
  stopSleepTimer();
  sleepTimer=setInterval(()=>{
    sleepPosition+=45;
    if(sleepPosition>=totalSleepSeconds()){sleepPosition=totalSleepSeconds();sleepPlaying=false;stopSleepTimer();}
    updateSleepPlaybackUI();
  },500);
}
function stopSleepTimer(){if(sleepTimer){clearInterval(sleepTimer);sleepTimer=null}}



let locationTimer=null;
let locationRefreshTimer=null;

const locationStatusMeta={
  normal:{short:'정상',full:'정상',color:'#48a985'},
  contact:{short:'연락',full:'연락 요청',color:'#e0a328'},
  help:{short:'도움',full:'도움 필요',color:'#ef8b46'},
  emergency:{short:'긴급',full:'긴급',color:'#e85b6d'}
};

let locationMembers=[
  {id:'self',nickname:'야모',self:true,status:'normal',lat:37.1490,lon:127.0770,lastSec:8,hasLocation:true},
  {id:'m1',nickname:'지민',self:false,status:'normal',lat:37.1562,lon:127.0828,lastSec:54,hasLocation:true},
  {id:'m2',nickname:'민수아빠회사동료김정우',self:false,status:'contact',lat:37.1780,lon:127.1050,lastSec:122,hasLocation:true},
  {id:'m3',nickname:'하늘',self:false,status:'help',lat:37.1250,lon:127.0350,lastSec:305,hasLocation:true},
  {id:'m4',nickname:'아직위치없는참여자',self:false,status:'normal',lat:null,lon:null,lastSec:null,hasLocation:false}
];

function escapeLoc(v=''){
  return String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function locationTop(live=false,label=''){
  return `<div class="move-sticky"><div class="move-header-row">
    <button id="locationBack" class="move-back-asset-btn"><img class="move-back-asset" src="${A}${live?'back-recording.png':'back-ready.png'}" alt="뒤로가기"></button>
    <img class="${live?'location-title-live':'location-title-prep'}" src="${A}${live?'title-location-live.png':'title-location.png'}" alt="${live?'위치공유 중':'위치공유'}">
    ${label?`<span class="loc-header-label">${label}</span>`:''}
  </div></div>`;
}
function selfLocationMember(){return locationMembers.find(x=>x.self)||null}
function sortedLocationMembers(){
  return [...locationMembers].sort((a,b)=>{
    if(a.self!==b.self)return a.self?-1:1;
    return a.nickname.localeCompare(b.nickname,'ko');
  });
}
function haversineKm(a,b){
  if(!a||!b||!a.hasLocation||!b.hasLocation||a.lat==null||a.lon==null||b.lat==null||b.lon==null)return null;
  const R=6371;
  const dLat=(b.lat-a.lat)*Math.PI/180;
  const dLon=(b.lon-a.lon)*Math.PI/180;
  const la1=a.lat*Math.PI/180,la2=b.lat*Math.PI/180;
  const q=Math.sin(dLat/2)**2+Math.cos(la1)*Math.cos(la2)*Math.sin(dLon/2)**2;
  return R*2*Math.atan2(Math.sqrt(q),Math.sqrt(1-q));
}
function distanceText(member){
  if(member.self)return '0.0 km';
  const d=haversineKm(selfLocationMember(),member);
  return d==null?'-':`${d.toFixed(1)} km`;
}
function lastTimeText(sec){
  if(sec==null)return '위치 대기';
  if(sec<20)return '방금 전';
  if(sec<60)return `${sec}초 전`;
  const m=Math.floor(sec/60);
  if(m<60)return `${m}분 전`;
  return `${Math.floor(m/60)}시간 전`;
}
function remainingLocationSeconds(){
  if(!locationShareUntil)return 0;
  return Math.max(0,Math.floor((locationShareUntil-Date.now())/1000));
}
function remainingLocationText(){
  const sec=remainingLocationSeconds();
  const h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60);
  if(h>0)return `${h}시간 ${m}분 남음`;
  return `${Math.max(0,m)}분 남음`;
}
function formatLocCountdown(sec){
  sec=Math.max(0,Math.floor(sec));
  const m=Math.floor(sec/60),s=sec%60;
  return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
}
function locationNetworkText(){
  if(!locationNetworkOnline)return '네트워크 연결 대기 중 · 마지막 위치 유지';
  if(!locationLastSnapshotAt)return '참여자 상태 확인 중';
  const sec=Math.max(0,Math.floor((Date.now()-locationLastSnapshotAt)/1000));
  return sec<10?'방금 갱신됨':`${sec}초 전 갱신`;
}
function locationExpiryWarningNeeded(){
  const rem=remainingLocationSeconds();
  return locationSharingActive&&rem>0&&rem<=300;
}
function bindLocationBack(target='main'){
  const b=document.getElementById('locationBack');
  if(!b)return;
  b.onclick=()=>{
    stopLocationTimers(true);
    if(target==='landing'){locationState='landing';render();return}
    if(target==='active'){locationState='active';render();return}
    view='main';
    tab=locationSharingActive?'home':'activity';
    setFocusMode(false);syncTabs();render();
  };
}

function locationLanding(){
  stopLocationTimers(true);
  setFocusMode(true);
  screen.innerHTML=`
    ${locationTop(false)}
    <section class="card loc-landing-hero">
      <img src="${A}activity-location.png" alt="">
      <h2>같은 방에 있는 사람끼리<br>마지막 위치를 확인해요</h2>
      <p>이동 경로가 아니라 각 참여자의 마지막 위치만 공유합니다.</p>
    </section>
    <div class="loc-menu-list">
      <button id="locCreateRoom" class="card loc-menu-card"><img src="${A}activity-location.png" alt=""><span>방 만들기</span></button>
      <button id="locJoinRoom" class="card loc-menu-card"><img src="${A}activity-location.png" alt=""><span>방 참여하기</span></button>
    </div>
    <div class="location-note"><b>개인정보 최소화</b><br>서버에는 각 참여자의 최신 위치만 유지하고 위치 이력과 이동 경로를 누적하지 않습니다.</div>
    <div class="location-note"><b>다른 활동과 동시 실행</b><br>걷기·달리기·자전거, Snow 등 다른 활동을 기록하는 동안에도 위치공유를 계속할 수 있습니다.</div>`;
  bindLocationBack('main');
  document.getElementById('locCreateRoom').onclick=()=>{locationCreateMode=true;locationRoomChecked=false;locationState='form';render()};
  document.getElementById('locJoinRoom').onclick=()=>{locationCreateMode=false;locationRoomChecked=true;locationState='form';render()};
}

function locationRoomForm(){
  stopLocationTimers(true);
  setFocusMode(true);
  screen.innerHTML=`
    ${locationTop(false,locationCreateMode?'방 만들기':'방 참여하기')}
    <div class="loc-form">
      <div class="move-section">방 이름</div>
      <div class="loc-room-row">
        <input id="locRoomName" class="alarm-input" maxlength="40" value="${escapeLoc(locationRoomName)}" placeholder="${locationCreateMode?'예: 야모네 스키 여행':'참여할 방 이름'}">
        ${locationCreateMode?`<button id="locCheckRoom" class="loc-small-action">중복 확인</button>`:''}
      </div>
      ${locationCreateMode?`<div id="locCheckResult" class="loc-check-result ${locationRoomChecked?'ok':''}">${locationRoomChecked?'사용 가능한 방 이름입니다. ✓':'방 이름 입력 후 중복 확인이 필요합니다.'}</div>`:''}

      <div class="move-section">내 닉네임</div>
      <input id="locNickname" class="alarm-input" maxlength="24" value="${escapeLoc(locationNickname)}" placeholder="예: 지민">

      <div class="move-section">방 비밀번호</div>
      <input id="locPassword" class="alarm-input" inputmode="numeric" maxlength="6" value="1234" placeholder="숫자 4~6자리">

      <div class="move-section">내 위치 전송 간격</div>
      <div class="loc-intervals">
        ${[60,180,300].map(v=>`<button class="loc-interval ${locationInterval===v?'active':''}" data-loc-interval="${v}">${v/60}분</button>`).join('')}
      </div>

      <div class="card loc-start-time-card">
        <div><b>첫 공유시간</b><small>공유 중 언제든 원하는 만큼 바로 연장할 수 있어요.</small></div>
        <strong>1시간</strong>
      </div>

      <div class="card loc-tech-card">
        <div><span>첫 위치</span><b>확보되면 빠르게 1회 전송</b></div>
        <div><span>이후 위치</span><b>${locationInterval/60}분 간격</b></div>
        <div><span>참여자 상태</span><b>60초 자동 갱신</b></div>
        <div><span>위치 수신</span><b>GPS + 네트워크 보조</b></div>
      </div>

      <div class="location-note"><b>첫 공유시간은 최소 1시간</b><br>공유 중 30분·1시간·2시간·3시간을 반복해서 추가할 수 있습니다.</div>
      <div class="location-note"><b>한 번에 한 방</b><br>동시에 여러 위치공유 방에는 참여하지 않습니다. 화면을 나가도 백그라운드에서 공유는 계속됩니다.</div>
      <button id="locSubmitRoom" class="location-start">${locationCreateMode?'방 만들기':'방 참여하기'}</button>
    </div>`;
  bindLocationBack('landing');

  const room=document.getElementById('locRoomName');
  const nick=document.getElementById('locNickname');
  room.oninput=e=>{locationRoomName=e.target.value;if(locationCreateMode)locationRoomChecked=false};
  nick.oninput=e=>locationNickname=e.target.value;

  document.querySelectorAll('[data-loc-interval]').forEach(b=>b.onclick=()=>{
    locationInterval=+b.dataset.locInterval;
    locationRoomName=room.value;
    locationNickname=nick.value;
    locationRoomForm();
  });

  const check=document.getElementById('locCheckRoom');
  if(check)check.onclick=()=>{
    locationRoomName=room.value.trim();
    const result=document.getElementById('locCheckResult');
    if(locationRoomName.length<2){
      locationRoomChecked=false;
      result.className='loc-check-result warn';
      result.textContent='방 이름을 2자 이상 입력해 주세요.';
    }else{
      locationRoomChecked=true;
      result.className='loc-check-result ok';
      result.textContent='사용 가능한 방 이름입니다. ✓';
    }
  };

  document.getElementById('locSubmitRoom').onclick=()=>{
    locationRoomName=room.value.trim();
    locationNickname=nick.value.trim()||'야모';
    const pw=document.getElementById('locPassword').value.trim();
    if(locationRoomName.length<2){say('방 이름을 2자 이상 입력해 주세요.');return}
    if(locationCreateMode&&!locationRoomChecked){say('방 이름 중복 확인을 먼저 해 주세요.');return}
    if(!/^\d{4,6}$/.test(pw)){say('비밀번호는 숫자 4~6자리로 입력해 주세요.');return}
    if(!locationPermissionGranted){openLocationPermissionSheet();return}
    startLocationSharing();
  };
}

function openLocationPermissionSheet(){
  moveOverlay.classList.add('show');
  moveOverlay.innerHTML=`<div class="move-sheet loc-permission-sheet">
    <div class="move-sheet-handle"></div>
    <h3>위치공유 권한</h3>
    <p>위치공유를 시작하려면 위치 권한이 필요합니다. 알림 권한을 허용하면 공유 종료 예정 및 도움·긴급 상태를 기기 알림과 진동으로 확인할 수 있습니다.</p>
    <div class="loc-permission-list">
      <div><b>위치</b><span>필수 · 현재 위치 공유</span></div>
      <div><b>알림</b><span>권장 · 종료/도움/긴급 알림</span></div>
    </div>
    <div class="move-sheet-actions">
      <button id="locPermissionCancel" class="move-sheet-cancel">취소</button>
      <button id="locPermissionAllow" class="move-sheet-stop" style="background:var(--primary);color:#fff">허용 후 시작</button>
    </div>
  </div>`;
  document.getElementById('locPermissionCancel').onclick=()=>closeMoveOverlay();
  document.getElementById('locPermissionAllow').onclick=()=>{
    locationPermissionGranted=true;
    locationNotificationGranted=true;
    closeMoveOverlay();
    startLocationSharing();
  };
}

function startLocationSharing(){
  locationSharingActive=true;
  locationStartAt=Date.now();
  locationShareUntil=Date.now()+60*60*1000;
  locationState='active';
  locationRefreshLeft=60;
  locationManualUnlockAt=Date.now()+10000;
  locationLastSnapshotAt=Date.now();
  locationInitialRefreshStep=0;
  locationExpiryWarned=false;
  locationNetworkOnline=true;
  locationMembers[0].nickname=locationNickname||'야모';
  locationMembers[0].status=locationOwnStatus;
  render();
  scheduleInitialLocationRefreshesMock();
}

function statusCounts(){
  const counts={normal:0,contact:0,help:0,emergency:0};
  locationMembers.forEach(m=>counts[m.status]=(counts[m.status]||0)+1);
  return counts;
}
function locParticipantRow(m){
  const stat=locationStatusMeta[m.status]||locationStatusMeta.normal;
  return `<button class="loc-participant-row ${locationSelectedMember===m.id?'selected':''}" data-member="${m.id}">
    <span class="loc-nickname" title="${escapeLoc(m.nickname)}">${escapeLoc(m.nickname)}${m.self?' (나)':''}</span>
    <span class="loc-dot" style="background:${stat.color}"></span>
    <span class="loc-status">${stat.short}</span>
    <span class="loc-sep">·</span>
    <span class="loc-distance">${distanceText(m)}</span>
    <span class="loc-sep">·</span>
    <span class="loc-last">${lastTimeText(m.lastSec)}</span>
  </button>`;
}
function selectedMember(){return locationMembers.find(x=>x.id===locationSelectedMember)||selfLocationMember()}
function locationMapMarkup(){
  const m=selectedMember();
  const stat=locationStatusMeta[m.status]||locationStatusMeta.normal;
  const positions={self:[48,56],m1:[61,38],m2:[76,25],m3:[27,71]};
  return `<div class="location-map-placeholder loc-real-map">
    <i class="location-map-road r1"></i><i class="location-map-road r2"></i><i class="location-map-road r3"></i>
    ${locationMembers.filter(x=>x.hasLocation).map(x=>{
      const p=positions[x.id]||[50,50];
      return `<button class="loc-map-member ${locationSelectedMember===x.id?'selected':''}" data-map-member="${x.id}" style="left:${p[0]}%;top:${p[1]}%"><span style="background:${locationStatusMeta[x.status].color}"></span></button>`;
    }).join('')}
  </div>
  <div class="loc-map-selected">
    <div class="loc-map-fullname">${escapeLoc(m.nickname)}${m.self?' (나)':''}</div>
    <div class="loc-map-meta"><span class="loc-dot" style="background:${stat.color}"></span>${stat.full} · ${distanceText(m)} · ${lastTimeText(m.lastSec)}</div>
  </div>`;
}

function locationActive(){
  setFocusMode(true);
  const counts=statusCounts();
  screen.innerHTML=`
    ${locationTop(true)}
    <div class="card loc-room-summary">
      <div><small>공유 중인 방</small><b>${escapeLoc(locationRoomName||'야모네 스키 여행')}</b></div>
      <span>${remainingLocationText()}</span>
    </div>

    <div class="card location-map-card">${locationMapMarkup()}</div>

    <div class="loc-status-summary">
      ${['normal','contact','help','emergency'].map(k=>`<div class="loc-summary-chip"><i style="background:${locationStatusMeta[k].color}"></i><span>${locationStatusMeta[k].short}</span><b>${counts[k]}명</b></div>`).join('')}
    </div>

    <div class="card loc-time-actions">
      <div class="loc-remaining"><small>남은 시간</small><strong id="locRemaining">${remainingLocationText()}</strong></div>
      <button id="locExtend" class="loc-soft-btn">시간 연장</button>
      <button id="locStop" class="loc-danger-btn">공유 중단</button>
    </div>

    <div class="card loc-participants-card">
      <div class="loc-participants-head">
        <b>참여자 (${locationMembers.length}명)</b>
        <button id="locOwnStatus" class="loc-own-status">내 상태 변경</button>
        <span id="locRefreshCount" class="loc-refresh-count">${formatLocCountdown(locationRefreshLeft)}</span>
        <button id="locManualRefresh" class="loc-refresh-btn" aria-label="참여자 상태 새로고침">↻</button>
      </div>
      <div class="loc-refresh-sub">
        <span id="locNetworkText">${locationNetworkText()}</span>
        <span id="locRefreshLabel">자동 갱신 ${formatLocCountdown(locationRefreshLeft)}</span>
      </div>
      <div class="loc-participant-list">${sortedLocationMembers().map(locParticipantRow).join('')}</div>
      <div class="loc-list-guide">닉네임 · 상태 · 나와의 직선거리 · 마지막 위치 시각</div>
    </div>

    ${locationExpiryWarningNeeded()?`<div class="loc-expiry-warning"><b>공유 종료까지 5분 이내</b><span>필요하면 지금 시간을 연장하세요.</span></div>`:''}

    <div class="card loc-service-card">
      <div><b>백그라운드 위치공유</b><small>화면을 나가도 위치공유가 계속됩니다.</small></div>
      <strong>실행 중</strong>
    </div>

    <div class="card loc-system-info">
      <div><span>내 위치 전송</span><b>${locationInterval/60}분 간격</b></div>
      <div><span>참여자 자동 갱신</span><b>60초</b></div>
      <div><span>수동 갱신</span><b>초기 10초 / 사용 후 30초 잠금</b></div>
      <div><span>초기 빠른 확인</span><b>1.5초 · 4초 · 8초</b></div>
      <div><span>종료 예정 알림</span><b>5분 전</b></div>
    </div>

    <div class="location-note"><b>마지막 위치만 유지</b><br>서버에는 각 참여자의 최신 위치만 유지합니다. 위치 이력이나 이동 경로를 쌓지 않습니다.</div>
    <div class="location-note"><b>네트워크가 끊기면</b><br>마지막으로 받은 위치를 화면에 유지하고 연결이 돌아오면 다시 갱신합니다.</div>`;
  bindLocationBack('main');
  bindLocationActiveActions();
  startLocationTimers();
}

function bindLocationActiveActions(){
  document.querySelectorAll('[data-member]').forEach(row=>row.onclick=()=>{
    locationSelectedMember=row.dataset.member;
    const m=selectedMember();
    if(!m.hasLocation){say(`${m.nickname}님의 위치를 아직 받지 못했어요.`);return}
    locationActive();
  });
  document.querySelectorAll('[data-map-member]').forEach(pin=>pin.onclick=()=>{
    locationSelectedMember=pin.dataset.mapMember;
    locationActive();
  });
  document.getElementById('locExtend').onclick=()=>{stopLocationTimers(false);locationState='extend';render()};
  document.getElementById('locStop').onclick=openLocationEnd;
  document.getElementById('locOwnStatus').onclick=openLocationStatusPicker;
  document.getElementById('locManualRefresh').onclick=manualLocationRefresh;
  updateManualRefreshButton();
}

function startLocationTimers(){
  stopLocationTimers(false);
  locationTimer=setInterval(()=>{
    if(!locationSharingActive||view!=='location'||locationState!=='active')return;
    const rem=document.getElementById('locRemaining');
    if(rem)rem.textContent=remainingLocationText();
    const nt=document.getElementById('locNetworkText');
    if(nt)nt.textContent=locationNetworkText();

    if(locationExpiryWarningNeeded()&&!locationExpiryWarned){
      locationExpiryWarned=true;
      say('위치공유 종료까지 5분 남았습니다. 필요하면 시간을 연장하세요.');
      locationActive();
      return;
    }
    if(remainingLocationSeconds()<=0){
      endLocationSharing(true);return;
    }
    locationMembers.forEach(m=>{if(m.lastSec!=null)m.lastSec+=1});
  },1000);

  locationRefreshTimer=setInterval(()=>{
    if(!locationSharingActive||view!=='location'||locationState!=='active')return;
    locationRefreshLeft=Math.max(0,locationRefreshLeft-1);
    const c=document.getElementById('locRefreshCount');
    if(c)c.textContent=formatLocCountdown(locationRefreshLeft);
    const label=document.getElementById('locRefreshLabel');
    if(label)label.textContent=`자동 갱신 ${formatLocCountdown(locationRefreshLeft)}`;
    updateManualRefreshButton();
    if(locationRefreshLeft<=0)performLocationRefresh(false);
  },1000);
}
function stopLocationTimers(clearFast=true){
  if(locationTimer){clearInterval(locationTimer);locationTimer=null}
  if(locationRefreshTimer){clearInterval(locationRefreshTimer);locationRefreshTimer=null}
  if(clearFast){
    locationFastRefreshTimers.forEach(t=>clearTimeout(t));
    locationFastRefreshTimers=[];
  }
}
function scheduleInitialLocationRefreshesMock(){
  locationFastRefreshTimers.forEach(t=>clearTimeout(t));
  locationFastRefreshTimers=[];
  [1500,4000,8000].forEach((delay,index)=>{
    const id=setTimeout(()=>{
      if(!locationSharingActive)return;
      locationInitialRefreshStep=index+1;
      locationLastSnapshotAt=Date.now();
      locationMembers.forEach((m,i)=>{
        if(m.lastSec!=null)m.lastSec=Math.min(m.lastSec,i===0?2:Math.max(5,m.lastSec-10));
      });
      if(view==='location'&&locationState==='active'){
        const nt=document.getElementById('locNetworkText');
        if(nt)nt.textContent=`초기 위치 빠른 갱신 ${index+1}/3 완료`;
      }
    },delay);
    locationFastRefreshTimers.push(id);
  });
}
function updateManualRefreshButton(){
  const b=document.getElementById('locManualRefresh');
  if(!b)return;
  const enabled=Date.now()>=locationManualUnlockAt;
  b.disabled=!enabled;
  b.classList.toggle('disabled',!enabled);
}
function manualLocationRefresh(){
  if(Date.now()<locationManualUnlockAt){say('잠시 후 다시 새로고침할 수 있어요.');return}
  performLocationRefresh(true);
}
function performLocationRefresh(manual){
  locationRefreshLeft=60;
  locationManualUnlockAt=Date.now()+30000;
  if(!locationNetworkOnline){
    say('네트워크 연결 대기 중입니다. 마지막으로 받은 위치를 유지합니다.');
    locationActive();
    return;
  }
  locationLastSnapshotAt=Date.now();
  locationMembers.forEach((m,i)=>{
    if(m.lastSec!=null)m.lastSec=Math.min(m.lastSec,i===0?3:Math.max(8,m.lastSec-35));
  });
  say(manual?'최신 참여자 상태를 확인했습니다.':'참여자 상태가 자동 갱신되었습니다.');
  locationActive();
}

function locationExtend(){
  stopLocationTimers(false);
  setFocusMode(true);
  screen.innerHTML=`
    ${locationTop(false,'공유 시간 연장')}
    <section class="card loc-extend-hero">
      <img src="${A}stat-time.png" alt="">
      <h2>얼마나 더 공유할까요?</h2>
      <p>현재 ${remainingLocationText()}</p>
    </section>
    <div class="loc-extend-grid">
      ${[30,60,120,180].map(v=>`<button class="loc-extend-choice ${locationExtendChoice===v?'active':''}" data-extend="${v}">${v===30?'30분':v/60+'시간'}</button>`).join('')}
    </div>
    <div class="location-note">연장은 여러 번 할 수 있습니다. 필요한 만큼 계속 추가할 수 있어요.</div>
    <button id="locApplyExtend" class="location-start">${locationExtendChoice===30?'30분':locationExtendChoice/60+'시간'} 연장하기</button>`;
  bindLocationBack('active');
  document.querySelectorAll('[data-extend]').forEach(b=>b.onclick=()=>{
    locationExtendChoice=+b.dataset.extend;locationExtend();
  });
  document.getElementById('locApplyExtend').onclick=()=>{
    locationShareUntil=(locationShareUntil||Date.now())+locationExtendChoice*60*1000;
    locationExpiryWarned=false;
    say('위치공유 시간을 연장했습니다.');
    locationState='active';locationRefreshLeft=60;render();
  };
}

function openLocationStatusPicker(){
  stopLocationTimers(false);
  moveOverlay.classList.add('show');
  moveOverlay.innerHTML=`<div class="move-sheet loc-status-sheet">
    <div class="move-sheet-handle"></div>
    <h3>내 상태 변경</h3>
    <p>현재 상태는 ${locationStatusMeta[locationOwnStatus].full}입니다.</p>
    <div class="loc-status-options">
      ${['normal','contact','help','emergency'].map(k=>`<button data-status-pick="${k}" class="${locationOwnStatus===k?'active':''}"><i style="background:${locationStatusMeta[k].color}"></i>${locationStatusMeta[k].full}</button>`).join('')}
    </div>
    <button id="locStatusClose" class="move-sheet-cancel" style="width:100%;margin-top:10px">닫기</button>
  </div>`;
  document.getElementById('locStatusClose').onclick=()=>{closeMoveOverlay();startLocationTimers()};
  document.querySelectorAll('[data-status-pick]').forEach(b=>b.onclick=()=>{
    const status=b.dataset.statusPick;
    if(status==='help'||status==='emergency'){confirmUrgentStatus(status);return}
    applyLocationStatus(status);
  });
  moveOverlay.onclick=e=>{if(e.target===moveOverlay){closeMoveOverlay();startLocationTimers()}};
}
function confirmUrgentStatus(status){
  moveOverlay.innerHTML=`<div class="move-sheet loc-status-sheet">
    <div class="move-sheet-handle"></div>
    <h3>${locationStatusMeta[status].full} 상태로 바꿀까요?</h3>
    <p>상태는 서버에 바로 반영되고 다른 참여자가 다음 갱신에서 확인합니다. 알림 권한이 있는 참여자에게 기기 알림과 진동으로 안내될 수 있습니다.</p>
    <div class="move-sheet-actions">
      <button id="locUrgentCancel" class="move-sheet-cancel">취소</button>
      <button id="locUrgentApply" class="move-sheet-stop">${locationStatusMeta[status].full}로 변경</button>
    </div>
  </div>`;
  document.getElementById('locUrgentCancel').onclick=()=>{closeMoveOverlay();startLocationTimers()};
  document.getElementById('locUrgentApply').onclick=()=>applyLocationStatus(status);
}
function applyLocationStatus(status){
  locationOwnStatus=status;
  const self=selfLocationMember();
  if(self)self.status=status;
  closeMoveOverlay();
  say(`내 상태를 ${locationStatusMeta[status].full}(으)로 변경했습니다.`);
  locationRefreshLeft=60;
  locationLastSnapshotAt=Date.now();
  locationActive();
}

function openLocationEnd(){
  stopLocationTimers(false);
  moveOverlay.classList.add('show');
  moveOverlay.innerHTML=`<div class="move-sheet"><div class="move-sheet-handle"></div>
    <h3>위치공유를 중단할까요?</h3>
    <p>중단하면 내 위치가 더 이상 다른 참여자에게 표시되지 않습니다.</p>
    <div class="move-sheet-actions"><button id="locationKeep" class="move-sheet-cancel">취소</button><button id="locationConfirmEnd" class="move-sheet-stop">공유 중단</button></div>
  </div>`;
  document.getElementById('locationKeep').onclick=()=>{closeMoveOverlay();startLocationTimers()};
  document.getElementById('locationConfirmEnd').onclick=()=>{closeMoveOverlay();endLocationSharing(false)};
  moveOverlay.onclick=e=>{if(e.target===moveOverlay){closeMoveOverlay();startLocationTimers()}};
}
function endLocationSharing(auto=false){
  stopLocationTimers(true);
  locationSharingActive=false;
  locationLastSnapshotAt=null;
  locationExpiryWarned=false;
  locationState='ended';
  render();
  if(auto)say('공유 시간이 끝나 위치공유를 종료했습니다.');
}
function locationEnded(){
  setFocusMode(true);
  screen.innerHTML=`
    ${locationTop(false)}
    <section class="card location-ended">
      <img src="${A}activity-location.png" alt="">
      <h2>위치공유 종료</h2>
      <p>내 위치의 추가 전송이 중지되었습니다.<br>이동 경로와 위치 이력은 저장하지 않습니다.</p>
    </section>
    <button id="locationDone" class="location-done">확인</button>`;
  bindLocationBack('main');
  document.getElementById('locationDone').onclick=()=>{
    locationState='landing';view='main';tab='activity';setFocusMode(false);syncTabs();render();
  };
}

function syncTabs(){tabs.forEach(x=>x.classList.toggle('active',x.dataset.tab===tab))}
function render(){
  if(view==='setting'){renderSettingDetail();return;}
  if(view==='record-detail'){
    renderRecordDetail();
    return;
  }
  if(view==='move'){
    if(moveState==='ready')moveReady();
    if(moveState==='recording')moveLive(false);
    if(moveState==='paused')moveLive(true);
    if(moveState==='summary')moveSummary();
    return;
  }
  if(view==='snow'){
    if(snowState==='ready')snowReady();
    if(snowState==='recording')snowLive(false);
    if(snowState==='paused')snowLive(true);
    if(snowState==='summary')snowSummary();
    return;
  }
  if(view==='sleep'){
    if(sleepState==='ready')sleepReady();
    if(sleepState==='recording')sleepLive();
    if(sleepState==='summary')sleepSummary();
    return;
  }
  if(view==='location'){
    if(locationState==='landing')locationLanding();
    if(locationState==='form')locationRoomForm();
    if(locationState==='active')locationActive();
    if(locationState==='extend')locationExtend();
    if(locationState==='ended')locationEnded();
    return;
  }
  setFocusMode(false);
  if(tab==='home')renderHome();
  if(tab==='activity')renderActivity();
  if(tab==='records')renderRecords();
  if(tab==='alarm')renderAlarm();
  if(tab==='settings')renderSettings();
}
tabs.forEach(x=>x.onclick=()=>{stopSleepTimer();stopLocationTimers(true);settingPage=null;view='main';moveState='ready';snowState='ready';sleepState='ready';sleepPlaying=false;alarmView='list';alarmDraft=null;ringingAlarmId=null;recordDetailId=null;tab=x.dataset.tab;syncTabs();render()});
buildAssetList();syncTabs();render();

function settingHeader(title){
  return `<div class="setting-detail-head">
    <button id="settingBack" class="setting-back"><img src="${A}back-ready.png" alt="뒤로가기"></button>
    <h1>${title}</h1>
  </div>`;
}
function settingToggle(id,title,sub,on,icon){
  return `<div class="card setting-control-row">
    ${icon?`<img class="setting-control-icon" src="${A}${icon}.png">`:''}
    <div class="setting-control-copy"><b>${title}</b>${sub?`<small>${sub}</small>`:''}</div>
    <button class="switch ${on?'on':''}" data-setting-toggle="${id}"></button>
  </div>`;
}
function settingChips(key,items,current){
  return `<div class="setting-chips">${items.map(([v,l])=>`<button class="${current===v?'active':''}" data-setting-chip="${key}" data-value="${v}">${l}</button>`).join('')}</div>`;
}
function settingSection(title,body){
  return `<div class="setting-section-title">${title}</div>${body}`;
}
function bindSettingCommon(){
  const back=document.getElementById('settingBack');
  if(back)back.onclick=()=>{
    settingPage=null;
    view='main';
    tab='settings';
    setFocusMode(false);
    syncTabs();
    render();
  };

  document.querySelectorAll('[data-setting-toggle]').forEach(btn=>btn.onclick=()=>{
    const k=btn.dataset.settingToggle;
    if(k==='autoDetect'){
      const next=!settingsState.autoDetect;
      settingsState.autoDetect=next;
      settingsState.detectWalk=next;
      settingsState.detectRun=next;
      settingsState.detectBike=next;
    }else if(['detectWalk','detectRun','detectBike'].includes(k)){
      settingsState[k]=!settingsState[k];
      settingsState.autoDetect=settingsState.detectWalk&&settingsState.detectRun&&settingsState.detectBike;
    }else{
      settingsState[k]=!settingsState[k];
    }
    renderSettingDetail();
  });

  document.querySelectorAll('[data-setting-chip]').forEach(btn=>btn.onclick=()=>{
    settingsState[btn.dataset.settingChip]=btn.dataset.value;
    renderSettingDetail();
  });
}

function renderAutoDetectSettings(){
  screen.innerHTML=`
    ${settingHeader('자동감지')}
    ${settingToggle('autoDetect','전체 자동감지','3가지 활동을 한 번에 설정',settingsState.autoDetect,'settings-auto-detect')}
    ${settingSection('활동별',
      settingToggle('detectWalk','걷기','',settingsState.detectWalk,'walk')+
      settingToggle('detectRun','달리기','',settingsState.detectRun,'run')+
      settingToggle('detectBike','자전거','',settingsState.detectBike,'bike')
    )}
    <div class="setting-info">전체를 바꾸면 3개가 같이 변경됩니다. 각 활동은 따로 바꿀 수 있어요.</div>`;
  bindSettingCommon();
}

function renderSnowSettings(){
  screen.innerHTML=`
    ${settingHeader('Snow')}
    ${settingToggle('snowAutoDetect','스키장 자동감지','스키장 진입 자동 감지',settingsState.snowAutoDetect,'settings-snow')}
    <div class="card setting-action-row">
      <img src="${A}route.png"><div><b>오프라인 지도</b><small>저장된 스키장 지도 관리</small></div>
      <button id="snowMapManage">관리</button>
    </div>`;
  bindSettingCommon();
  document.getElementById('snowMapManage').onclick=()=>say('오프라인 지도 관리 화면 목업입니다.');
}

function renderSleepSettings(){
  screen.innerHTML=`
    ${settingHeader('수면')}
    ${settingToggle('sleepSnore','코골이 감지','코골이 후보 구간 표시',settingsState.sleepSnore,'settings-sleep')}
    ${settingSection('감지 민감도',`<div class="card setting-block">${settingChips('sleepSensitivity',[['low','낮음'],['normal','보통'],['high','높음']],settingsState.sleepSensitivity)}</div>`)}`;
  bindSettingCommon();
}

function renderAlarmSettings(){
  screen.innerHTML=`
    ${settingHeader('알람')}
    ${settingSection('기본 스누즈',`<div class="card setting-block">${settingChips('alarmSnooze',[['5','5분'],['10','10분'],['15','15분']],settingsState.alarmSnooze)}</div>`)}
    ${settingToggle('alarmVibrate','진동','',settingsState.alarmVibrate,'settings-alarm')}`;
  bindSettingCommon();
}

function renderPermissionSettings(){
  screen.innerHTML=`
    ${settingHeader('권한')}
    <div class="setting-permission-list">
      <div class="card setting-permission-row"><img src="${A}gps.png"><div><b>위치</b><small>활동 · Snow</small></div><strong>확인</strong><button data-permission="위치">설정</button></div>
      <div class="card setting-permission-row"><img src="${A}nav-alarm.png"><div><b>알림</b><small>알람 · 상태</small></div><strong>확인</strong><button data-permission="알림">설정</button></div>
      <div class="card setting-permission-row"><img src="${A}settings-sleep.png"><div><b>마이크</b><small>수면</small></div><strong>확인</strong><button data-permission="마이크">설정</button></div>
      <div class="card setting-permission-row"><img src="${A}settings-permission.png"><div><b>백그라운드</b><small>장시간 기록</small></div><strong>확인</strong><button data-permission="백그라운드">설정</button></div>
    </div>`;
  bindSettingCommon();
  document.querySelectorAll('[data-permission]').forEach(b=>b.onclick=()=>say(`${b.dataset.permission} 권한 설정 화면 목업입니다.`));
}

function renderDataSettings(){
  screen.innerHTML=`
    ${settingHeader('데이터 / 저장')}
    <div class="section">저장공간</div>
    <div class="card storage-card">
      <div><span>이동 활동</span><strong>1.1 MB</strong></div>
      <div><span>Snow</span><strong>5.2 MB</strong></div>
      <div><span>수면</span><strong>12.1 MB</strong></div>
      <div class="storage-total"><span>총 사용량</span><strong>18.4 MB</strong></div>
    </div>
    <div class="section">기록 전체 삭제</div>
    <div class="setting-delete-stack">
      <button class="card setting-delete-row" data-delete-kind="이동 활동"><img src="${A}settings-activity-record.png"><div><b>이동 활동 기록 전체 삭제</b><small>걷기 · 달리기 · 자전거</small></div><span>삭제</span></button>
      <button class="card setting-delete-row" data-delete-kind="Snow"><img src="${A}settings-snow.png"><div><b>Snow 기록 전체 삭제</b><small>모든 Snow 기록</small></div><span>삭제</span></button>
      <button class="card setting-delete-row" data-delete-kind="수면"><img src="${A}settings-sleep.png"><div><b>수면 기록 전체 삭제</b><small>모든 수면 기록</small></div><span>삭제</span></button>
    </div>`;
  bindSettingCommon();
  document.querySelectorAll('[data-delete-kind]').forEach(b=>b.onclick=()=>openSettingsDeleteConfirm(b.dataset.deleteKind));
}

function openSettingsDeleteConfirm(kind){
  moveOverlay.classList.add('show');
  moveOverlay.innerHTML=`
    <div class="move-sheet">
      <div class="move-sheet-handle"></div>
      <h3>${kind} 기록을 모두 삭제할까요?</h3>
      <p>삭제한 기록은 복구할 수 없습니다.</p>
      <div class="move-sheet-actions">
        <button id="settingsDeleteCancel" class="move-sheet-cancel">취소</button>
        <button id="settingsDeleteConfirm" class="move-sheet-stop">전체 삭제</button>
      </div>
    </div>`;
  document.getElementById('settingsDeleteCancel').onclick=closeMoveOverlay;
  document.getElementById('settingsDeleteConfirm').onclick=()=>{
    closeMoveOverlay();
    say(`${kind} 기록 전체 삭제 목업입니다.`);
  };
  moveOverlay.onclick=e=>{if(e.target===moveOverlay)closeMoveOverlay()};
}

function renderAppInfoSettings(){
  const unlocked=appInfoTapCount>=7;
  screen.innerHTML=`
    ${settingHeader('앱 정보')}
    <button id="appVersionTap" class="card app-info-card">
      <img src="${A}nav-settings.png"><div><b>야모네 활동 앱</b><small>Version 0.00.23</small></div>
    </button>
    <div class="setting-action-stack">
      <button class="card setting-wide-action"><b>이용 안내</b><span>›</span></button>
      <button class="card setting-wide-action"><b>개인정보 안내</b><span>›</span></button>
      <button class="card setting-wide-action"><b>오픈소스 라이선스</b><span>›</span></button>
    </div>
    ${unlocked?`<div class="section">개발자 모드</div><div class="card setting-block"><div class="dev-grid"><button>시간 가속</button><button>자동감지</button><button>GPS 손실</button><button>Snow 하루</button><button>수면 시간</button></div></div>`:''}`;
  bindSettingCommon();
  document.getElementById('appVersionTap').onclick=()=>{
    appInfoTapCount++;
    if(appInfoTapCount>=7)renderAppInfoSettings();
  };
}

function renderSettingDetail(){
  setFocusMode(true);
  if(settingPage==='자동감지')return renderAutoDetectSettings();
  if(settingPage==='Snow')return renderSnowSettings();
  if(settingPage==='수면')return renderSleepSettings();
  if(settingPage==='알람')return renderAlarmSettings();
  if(settingPage==='권한')return renderPermissionSettings();
  if(settingPage==='데이터 / 저장')return renderDataSettings();
  if(settingPage==='앱 정보')return renderAppInfoSettings();
  settingPage=null;view='main';render();
}

